package com.ndrx.mic

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

/**
 * Accessibility service: injects the taps and hosts all floating UI
 * (control panel, number pad, detection dots, layout editor).
 */
class ClickService : AccessibilityService() {
    companion object {
        @Volatile var instance: ClickService? = null
    }

    private val main = Handler(Looper.getMainLooper())
    private lateinit var wm: WindowManager
    private var lc: Context? = null

    @Volatile var panelVisible = false
        private set
    private var collapsed = false

    private var panel: View? = null
    private var pad: View? = null
    private var padKey = ""
    private var dots: DotsView? = null
    private var editor: View? = null

    private val chips = arrayOfNulls<TextView>(4)
    private var startBtn: TextView? = null
    private var dotsBtn: TextView? = null
    private var status: TextView? = null
    private var led: View? = null
    private var body: View? = null

    private val dotsLoop = object : Runnable {
        override fun run() {
            val d = dots ?: return
            d.invalidate()
            main.postDelayed(this, 120)
        }
    }

    // ---------------------------------------------------------------- lifecycle
    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        Engine.load()
        Engine.onStatus = { msg -> main.post { status?.text = msg; status?.setTextColor(UiKit.ACCENT) } }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    override fun onUnbind(intent: Intent?): Boolean {
        tearDown()
        instance = null
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        tearDown()
        instance = null
        super.onDestroy()
    }

    private fun tearDown() {
        Engine.armed = false
        removeView(panel); panel = null
        removePad(); removeDots(); removeEditor()
        panelVisible = false
    }

    // ---------------------------------------------------------------- tapping
    fun tap(x: Float, y: Float, twice: Boolean) {
        val path = Path()
        path.moveTo(x, y)
        val b = GestureDescription.Builder()
        b.addStroke(GestureDescription.StrokeDescription(path, 0, 8))
        if (twice) {
            val p2 = Path()
            p2.moveTo(x, y)
            b.addStroke(GestureDescription.StrokeDescription(p2, 80, 8))
        }
        dispatchGesture(b.build(), null, null)
    }

    // ---------------------------------------------------------------- public API
    fun showPanel() {
        main.post {
            if (panelVisible) { refreshUi(); return@post }
            lc = Loc.wrap(this)
            Engine.load()
            buildPanel()
            panelVisible = true
            refreshUi()
        }
    }

    fun hidePanel() {
        main.post {
            tearDown()
        }
    }

    /** Called when settings, capture state or layout changed. */
    fun refreshUi() {
        main.post {
            if (!panelVisible) return@post
            val c = lc ?: return@post
            val isPad = Engine.mode == Engine.PAD
            for (i in 0..3) chips[i]?.let { styleChip(it, i == Engine.mode) }
            val armed = Engine.armed && !isPad
            startBtn?.visibility = if (isPad) View.GONE else View.VISIBLE
            startBtn?.text = c.getString(if (armed) R.string.p_stop else R.string.p_start)
            startBtn?.background = UiKit.bg(c, if (armed) UiKit.DANGER else UiKit.ACCENT, 8)
            startBtn?.setTextColor(if (armed) Color.WHITE else Color.WHITE)
            led?.background = oval(if (armed || isPad) UiKit.ACCENT else 0xFF5A3A3E.toInt())
            val needCap = !isPad && !Engine.capturing
            status?.text = when {
                needCap -> c.getString(R.string.p_nocap)
                armed -> c.getString(R.string.p_armed)
                isPad -> ""
                else -> c.getString(R.string.p_idle)
            }
            status?.setTextColor(if (needCap) UiKit.DANGER else UiKit.MUTED)
            status?.visibility = if (isPad) View.GONE else View.VISIBLE
            dotsBtn?.let { styleChip(it, Prefs.dots) }
            if (isPad && editor == null) showPad() else removePad()
            if (Prefs.dots && Engine.capturing && !isPad && editor == null) showDots() else removeDots()
        }
    }

    // ---------------------------------------------------------------- panel
    private fun d(v: Int) = UiKit.dp(this, v)

    private fun overlayLp(w: Int, h: Int, flags: Int): WindowManager.LayoutParams {
        val lp = WindowManager.LayoutParams(w, h, WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY, flags, PixelFormat.TRANSLUCENT)
        lp.gravity = Gravity.TOP or Gravity.START
        return lp
    }

    private fun oval(color: Int): GradientDrawable {
        val g = GradientDrawable()
        g.shape = GradientDrawable.OVAL
        g.setColor(color)
        return g
    }

    private fun styleChip(t: TextView, on: Boolean) {
        val c = lc ?: return
        t.setTextColor(if (on) Color.WHITE else UiKit.TEXT)
        t.background = UiKit.bg(c, if (on) UiKit.ACCENT else 0xFF2B1416.toInt(), 8)
    }

    private fun chip(text: String, onClick: () -> Unit): TextView {
        val c = lc!!
        val t = UiKit.tv(c, text, 12f, UiKit.TEXT, true)
        t.gravity = Gravity.CENTER
        t.setPadding(d(8), d(8), d(8), d(8))
        t.background = UiKit.bg(c, 0xFF2B1416.toInt(), 8)
        t.setOnClickListener { onClick() }
        return t
    }

    private fun smallBtn(text: String, onClick: () -> Unit): TextView {
        val t = chip(text, onClick)
        t.textSize = 14f
        t.minWidth = d(34)
        return t
    }

    private fun dragBy(handle: View, target: View, lp: WindowManager.LayoutParams) {
        var sx = 0f
        var sy = 0f
        var ox = 0
        var oy = 0
        handle.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; ox = lp.x; oy = lp.y }
                MotionEvent.ACTION_MOVE -> {
                    lp.x = ox + (e.rawX - sx).toInt()
                    lp.y = oy + (e.rawY - sy).toInt()
                    try { wm.updateViewLayout(target, lp) } catch (_: Exception) {}
                }
            }
            true
        }
    }

    private fun dirFlag(): Int = if (Loc.isAr()) View.LAYOUT_DIRECTION_RTL else View.LAYOUT_DIRECTION_LTR

    private fun buildPanel() {
        val c = lc!!
        val root = LinearLayout(c)
        root.orientation = LinearLayout.VERTICAL
        root.layoutDirection = dirFlag()
        root.background = UiKit.bg(c, 0xF2100506.toInt(), 14, 0xFF6A1822.toInt(), 1)
        root.setPadding(d(8), d(6), d(8), d(8))
        root.minimumWidth = d(190)

        val head = LinearLayout(c)
        head.orientation = LinearLayout.HORIZONTAL
        head.gravity = Gravity.CENTER_VERTICAL
        head.setPadding(0, d(2), 0, d(6))
        val ledV = View(c)
        led = ledV
        val ledLp = LinearLayout.LayoutParams(d(10), d(10))
        ledLp.marginEnd = d(6)
        head.addView(ledV, ledLp)
        head.addView(UiKit.tv(c, "ndrXmic ⠿", 12f, UiKit.ACCENT, true, true),
            LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        head.addView(smallBtn("–") { toggleCollapse() })
        val xLp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        xLp.marginStart = d(4)
        head.addView(smallBtn("✕") { closeAll() }, xLp)

        val bodyL = LinearLayout(c)
        bodyL.orientation = LinearLayout.VERTICAL
        val modes = LinearLayout(c)
        modes.orientation = LinearLayout.HORIZONTAL
        val names = intArrayOf(R.string.p_open, R.string.p_follow, R.string.p_pad, R.string.p_watch)
        for (i in 0..3) {
            val t = chip(c.getString(names[i])) { setMode(i) }
            chips[i] = t
            val lp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            lp.setMargins(d(2), 0, d(2), 0)
            modes.addView(t, lp)
        }
        bodyL.addView(modes)

        val act = LinearLayout(c)
        act.orientation = LinearLayout.HORIZONTAL
        act.gravity = Gravity.CENTER_VERTICAL
        act.setPadding(0, d(6), 0, d(4))
        val sb = UiKit.tv(c, "", 13f, Color.WHITE, true)
        sb.gravity = Gravity.CENTER
        sb.setPadding(d(10), d(8), d(10), d(8))
        sb.setOnClickListener { toggleArm() }
        startBtn = sb
        val sbLp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        sbLp.setMargins(d(2), 0, d(4), 0)
        act.addView(sb, sbLp)
        val db = smallBtn("◉") { Prefs.dots = !Prefs.dots; refreshUi() }
        dotsBtn = db
        act.addView(db)
        val eLp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        eLp.marginStart = d(4)
        act.addView(smallBtn("✎") { startEditor() }, eLp)
        bodyL.addView(act)

        val st = UiKit.tv(c, "", 11f, UiKit.MUTED, false, true)
        st.setOnClickListener { onStatusTap() }
        status = st
        bodyL.addView(st)

        body = bodyL
        root.addView(head)
        root.addView(bodyL)
        bodyL.visibility = if (collapsed) View.GONE else View.VISIBLE

        val lp = overlayLp(
            ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
        )
        lp.x = d(8)
        lp.y = (screenHeight() * 0.56f).toInt()
        dragBy(head, root, lp)
        wm.addView(root, lp)
        panel = root
    }

    private fun screenHeight(): Float {
        val m = resources.displayMetrics
        return Math.max(m.widthPixels, m.heightPixels).toFloat()
    }

    private fun toggleCollapse() {
        collapsed = !collapsed
        body?.visibility = if (collapsed) View.GONE else View.VISIBLE
    }

    private fun setMode(i: Int) {
        Prefs.mode = i
        Engine.mode = i
        if (i == Engine.PAD) Engine.armed = false
        refreshUi()
    }

    private fun toggleArm() {
        if (!Engine.capturing) { onStatusTap(); return }
        Engine.armed = !Engine.armed
        refreshUi()
    }

    private fun onStatusTap() {
        if (Engine.mode != Engine.PAD && !Engine.capturing) {
            val i = Intent(this, MainActivity::class.java)
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            i.putExtra("capture", true)
            try { startActivity(i) } catch (_: Exception) {
                Toast.makeText(lc ?: this, R.string.p_nocap, Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun closeAll() {
        stopService(Intent(this, CaptureService::class.java))
        Engine.capturing = false
        tearDown()
    }

    // ---------------------------------------------------------------- number pad
    private fun showPad() {
        val c = lc ?: return
        val n = Engine.slots.size
        if (n == 0) return
        val key = "$n/${Prefs.padSize}/${Loc.lang()}"
        if (pad != null && key == padKey) return
        removePad()
        padKey = key

        val rows = (n + 4) / 5
        val cols = (n + rows - 1) / rows
        val cell = d(intArrayOf(38, 46, 54)[Prefs.padSize.coerceIn(0, 2)])

        val box = LinearLayout(c)
        box.orientation = LinearLayout.VERTICAL
        box.layoutDirection = View.LAYOUT_DIRECTION_RTL   // numbers run right -> left like the game
        box.background = UiKit.bg(c, 0xCC100506.toInt(), 12, 0xFF6A1822.toInt(), 1)
        box.setPadding(d(4), d(2), d(4), d(4))

        val handle = UiKit.tv(c, "⠿⠿⠿", 14f, UiKit.ACCENT, true)
        handle.gravity = Gravity.CENTER
        handle.setPadding(0, d(2), 0, d(2))
        box.addView(handle, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        var k = 0
        for (r in 0 until rows) {
            val rowL = LinearLayout(c)
            rowL.orientation = LinearLayout.HORIZONTAL
            rowL.layoutDirection = View.LAYOUT_DIRECTION_RTL
            for (q in 0 until cols) {
                if (k >= n) break
                val idx = k
                val b = UiKit.tv(c, (k + 1).toString(), if (cell > d(46)) 20f else 17f, Color.WHITE, true)
                b.gravity = Gravity.CENTER
                b.background = UiKit.pressable(
                    UiKit.bg(c, 0xFF22100F.toInt(), 10, 0xFF7A1C28.toInt(), 1),
                    UiKit.bg(c, UiKit.ACCENT, 10)
                )
                b.setOnTouchListener { v, e ->
                    when (e.actionMasked) {
                        MotionEvent.ACTION_DOWN -> { v.isPressed = true; Engine.tapSlot(idx) }
                        MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> v.isPressed = false
                    }
                    true
                }
                val lp = LinearLayout.LayoutParams(cell, cell)
                lp.setMargins(d(2), d(2), d(2), d(2))
                rowL.addView(b, lp)
                k++
            }
            box.addView(rowL)
        }

        val lp = overlayLp(
            ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
        )
        val padW = cols * (cell + d(4)) + d(8)
        val padH = rows * (cell + d(4)) + d(24)
        lp.x = (Engine.screenW - padW - d(8)).toInt().coerceAtLeast(0)
        lp.y = (screenHeight() * 0.93f - padH).toInt()
        dragBy(handle, box, lp)
        wm.addView(box, lp)
        pad = box
    }

    private fun removePad() {
        removeView(pad)
        pad = null
        padKey = ""
    }

    // ---------------------------------------------------------------- dots
    private fun showDots() {
        if (dots != null) return
        val c = lc ?: return
        val v = DotsView(c)
        val lp = overlayLp(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
        )
        wm.addView(v, lp)
        dots = v
        main.postDelayed(dotsLoop, 120)
    }

    private fun removeDots() {
        main.removeCallbacks(dotsLoop)
        removeView(dots)
        dots = null
    }

    // ---------------------------------------------------------------- editor
    private fun startEditor() {
        if (editor != null) return
        val c = lc ?: return
        removePad(); removeDots()
        val v = EditorView(c, onDone = { list ->
            if (list.isEmpty()) {
                Toast.makeText(c, R.string.ed_need, Toast.LENGTH_SHORT).show()
            } else {
                Prefs.custom = Layouts.serialize(list)
                Prefs.layoutId = "custom"
                Engine.load()
                Toast.makeText(c, R.string.ed_saved, Toast.LENGTH_SHORT).show()
                removeEditor()
                refreshUi()
            }
        }, onCancel = {
            removeEditor()
            refreshUi()
        })
        v.layoutDirection = dirFlag()
        val lp = overlayLp(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
        )
        wm.addView(v, lp)
        editor = v
    }

    private fun removeEditor() {
        removeView(editor)
        editor = null
    }

    private fun removeView(v: View?) {
        if (v == null) return
        try { wm.removeView(v) } catch (_: Exception) {}
    }
}
