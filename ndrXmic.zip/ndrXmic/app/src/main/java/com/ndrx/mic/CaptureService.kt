package com.ndrx.mic

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.util.DisplayMetrics
import android.view.WindowManager

/** Foreground service that mirrors the screen at half resolution and feeds every frame to the Engine. */
class CaptureService : Service() {
    private var projection: MediaProjection? = null
    private var reader: ImageReader? = null
    private var display: VirtualDisplay? = null
    private var thread: HandlerThread? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent == null || intent.action == "STOP") { stopSelf(); return START_NOT_STICKY }
        startAsForeground()

        val code = intent.getIntExtra("code", 0)
        val data = if (Build.VERSION.SDK_INT >= 33)
            intent.getParcelableExtra("data", Intent::class.java)
        else @Suppress("DEPRECATION") intent.getParcelableExtra<Intent>("data")
        if (data == null) { stopSelf(); return START_NOT_STICKY }

        val t = HandlerThread("ndrx-capture", android.os.Process.THREAD_PRIORITY_URGENT_DISPLAY)
        t.start()
        thread = t
        val bg = Handler(t.looper)

        val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        val proj = mpm.getMediaProjection(code, data)
        projection = proj
        proj.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() { stopSelf() }
        }, bg)

        val wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val dm = DisplayMetrics()
        @Suppress("DEPRECATION") wm.defaultDisplay.getRealMetrics(dm)
        val w = (dm.widthPixels / 2) and 1.inv()
        val h = (dm.heightPixels / 2) and 1.inv()
        Engine.screenW = Math.min(dm.widthPixels, dm.heightPixels).toFloat()

        val r = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 3)
        reader = r
        display = proj.createVirtualDisplay(
            "ndrx", w, h, dm.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, r.surface, null, bg
        )
        r.setOnImageAvailableListener({ rd ->
            val img = rd.acquireLatestImage()
            if (img != null) {
                try {
                    if (true) {
                        val p = img.planes[0]
                        Engine.onFrame(Frame(p.buffer, img.width, img.height, p.rowStride, p.pixelStride))
                    }
                } finally {
                    img.close()
                }
            }
        }, bg)

        Engine.capturing = true
        ClickService.instance?.refreshUi()
        return START_NOT_STICKY
    }

    private fun startAsForeground() {
        val lc = Loc.wrap(this)
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("ndrx", "NMic", NotificationManager.IMPORTANCE_LOW))
        val stop = PendingIntent.getService(
            this, 1, Intent(this, CaptureService::class.java).setAction("STOP"),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = Notification.Builder(this, "ndrx")
            .setContentTitle(lc.getString(R.string.notif_title))
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .addAction(Notification.Action.Builder(android.R.drawable.ic_delete, lc.getString(R.string.notif_stop), stop).build())
            .build()
        if (Build.VERSION.SDK_INT >= 29)
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        else startForeground(1, n)
    }

    override fun onDestroy() {
        Engine.armed = false
        Engine.capturing = false
        try { reader?.setOnImageAvailableListener(null, null) } catch (_: Exception) {}
        display?.release()
        reader?.close()
        projection?.stop()
        thread?.quitSafely()
        ClickService.instance?.refreshUi()
        super.onDestroy()
    }
}
