package com.ndrx.mic

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.LinearLayout

/**
 * One square frame + numbered tag per seat, drawn on the exact spot the app is reading:
 * red = locked, green = open, white = taken, yellow = unsure.
 * If a frame does not sit on its seat, use the arrows in the panel to move them.
 */
class DotsView(ctx: Context) : View(ctx) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val tp = Paint(Paint.ANTI_ALIAS_FLAG)

    init {
        tp.textAlign = Paint.Align.CENTER
        tp.typeface = UiKit.font(ctx)
        tp.textSize = UiKit.dp(ctx, 10).toFloat()
    }

    override fun onDraw(c: Canvas) {
        val loc = IntArray(2)
        getLocationOnScreen(loc)
        val sw = Engine.screenW
        val slots = Engine.slots
        val st = Engine.snapshot()
        val tag = UiKit.dp(context, 15).toFloat()
        for (i in slots.indices) {
            val s = slots[i]
            val cx = s.x * sw - loc[0]
            val cy = s.y * sw - loc[1]
            val half = s.r * sw * 1.05f
            val col = when (st.getOrNull(i)) {
                Classifier.LOCKED -> UiKit.DANGER
                Classifier.EMPTY -> UiKit.OPEN
                Classifier.OCC -> UiKit.BLUE
                else -> UiKit.YELLOW
            }
            val fo = Engine.focus
            val isFocus = i == fo
            p.style = Paint.Style.STROKE
            p.strokeWidth = UiKit.dp(context, if (isFocus) 3 else 1).toFloat() + 0.5f
            p.color = if (fo >= 0 && !isFocus) (col and 0x00FFFFFF) or 0x55000000 else col
            c.drawRect(cx - half, cy - half, cx + half, cy + half, p)
            p.style = Paint.Style.FILL
            c.drawRect(cx - half, cy - half, cx - half + tag, cy - half + tag, p)
            tp.color = Color.BLACK
            c.drawText((i + 1).toString(), cx - half + tag / 2f, cy - half + tag * 0.74f, tp)
        }
    }
}

/** Full-screen helper to place custom mic positions by tapping their centers. */
class EditorView(
    ctx: Context,
    private val onDone: (List<Slot>) -> Unit,
    private val onCancel: () -> Unit
) : FrameLayout(ctx) {
    private val pts = ArrayList<Slot>()
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val tp = Paint(Paint.ANTI_ALIAS_FLAG)
    private val sw: Float = Engine.screenW

    private val canvasView = object : View(ctx) {
        override fun onDraw(c: Canvas) { drawAll(c, this) }
        override fun onTouchEvent(e: MotionEvent): Boolean {
            if (e.actionMasked == MotionEvent.ACTION_DOWN) {
                tap(e.rawX / sw, e.rawY / sw)
                invalidate()
            }
            return true
        }
    }

    init {
        tp.color = Color.WHITE
        tp.textAlign = Paint.Align.CENTER
        tp.typeface = UiKit.font(ctx)
        tp.textSize = UiKit.dp(ctx, 16).toFloat()
        addView(canvasView, LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        val bar = LinearLayout(ctx)
        bar.orientation = LinearLayout.HORIZONTAL
        bar.gravity = Gravity.CENTER
        bar.setBackgroundColor(0xF2000000.toInt())
        bar.setPadding(UiKit.dp(ctx, 8), UiKit.dp(ctx, 8), UiKit.dp(ctx, 8), UiKit.dp(ctx, 8))
        fun b(text: Int, bgc: Int, fg: Int, f: () -> Unit) {
            val t = UiKit.tv(ctx, ctx.getString(text), 13f, fg, true)
            t.gravity = Gravity.CENTER
            t.setPadding(UiKit.dp(ctx, 8), UiKit.dp(ctx, 10), UiKit.dp(ctx, 8), UiKit.dp(ctx, 10))
            t.background = UiKit.bg(ctx, bgc, 0, UiKit.ACCENT, 1)
            t.setOnClickListener { f() }
            val lp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            lp.setMargins(UiKit.dp(ctx, 3), 0, UiKit.dp(ctx, 3), 0)
            bar.addView(t, lp)
        }
        b(R.string.ed_undo, UiKit.BG, UiKit.TEXT) { if (pts.isNotEmpty()) pts.removeAt(pts.size - 1); canvasView.invalidate() }
        b(R.string.ed_clear, UiKit.BG, UiKit.TEXT) { pts.clear(); canvasView.invalidate() }
        b(R.string.ed_cancel, UiKit.BG, UiKit.TEXT) { onCancel() }
        b(R.string.ed_done, UiKit.ACCENT, UiKit.ON_ACCENT) { onDone(Layouts.sortReading(pts)) }
        val lp = LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.gravity = Gravity.BOTTOM
        lp.bottomMargin = UiKit.dp(ctx, 56)
        addView(bar, lp)
    }

    private fun tap(ux: Float, uy: Float) {
        for (i in pts.indices) {
            val s = pts[i]
            val dx = s.x - ux
            val dy = s.y - uy
            if (Math.sqrt((dx * dx + dy * dy).toDouble()) < s.r * 0.8) { pts.removeAt(i); return }
        }
        pts.add(Slot(ux, uy, 0.0694f))
    }

    private fun drawAll(c: Canvas, v: View) {
        val loc = IntArray(2)
        v.getLocationOnScreen(loc)
        c.drawColor(0x88000000.toInt())
        val sorted = Layouts.sortReading(pts)
        for (i in sorted.indices) {
            val s = sorted[i]
            val cx = s.x * sw - loc[0]
            val cy = s.y * sw - loc[1]
            p.style = Paint.Style.FILL
            p.color = 0x44FFFFFF
            c.drawCircle(cx, cy, s.r * sw, p)
            p.style = Paint.Style.STROKE
            p.strokeWidth = UiKit.dp(context, 2).toFloat()
            p.color = UiKit.ACCENT
            c.drawCircle(cx, cy, s.r * sw, p)
            c.drawText((i + 1).toString(), cx, cy + tp.textSize / 3f, tp)
        }
        tp.textSize = UiKit.dp(context, 14).toFloat()
        c.drawText(context.getString(R.string.ed_hint), v.width / 2f, UiKit.dp(context, 90).toFloat(), tp)
        tp.textSize = UiKit.dp(context, 16).toFloat()
    }
}

/** Mini schematic of a layout, used in the layout picker. */
class LayoutPreview(ctx: Context, private val slots: List<Slot>, private val sel: Boolean) : View(ctx) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val tp = Paint(Paint.ANTI_ALIAS_FLAG)

    init {
        tp.textAlign = Paint.Align.CENTER
        tp.typeface = UiKit.font(ctx)
    }

    override fun onDraw(c: Canvas) {
        if (slots.isEmpty()) {
            tp.color = Color.WHITE
            tp.textSize = UiKit.dp(context, 28).toFloat()
            c.drawText("?", width / 2f, height / 2f + tp.textSize / 3f, tp)
            return
        }
        val minX = slots.minOf { it.x - it.r }
        val maxX = slots.maxOf { it.x + it.r }
        val minY = slots.minOf { it.y - it.r }
        val maxY = slots.maxOf { it.y + it.r }
        val pad = UiKit.dp(context, 6).toFloat()
        val sc = Math.min((width - 2 * pad) / (maxX - minX), (height - 2 * pad) / (maxY - minY))
        val ox = (width - (maxX - minX) * sc) / 2f - minX * sc
        val oy = (height - (maxY - minY) * sc) / 2f - minY * sc
        for (i in slots.indices) {
            val s = slots[i]
            val cx = ox + s.x * sc
            val cy = oy + s.y * sc
            val r = s.r * sc
            p.style = Paint.Style.FILL
            p.color = if (s.host) 0xFF3A3A3A.toInt() else UiKit.ACCENT_DIM
            c.drawCircle(cx, cy, r, p)
            p.style = Paint.Style.STROKE
            p.strokeWidth = UiKit.dp(context, 1).toFloat()
            p.color = if (sel) UiKit.ACCENT else 0xFF666666.toInt()
            c.drawCircle(cx, cy, r, p)
            tp.color = Color.WHITE
            tp.textSize = r * 0.95f
            c.drawText((i + 1).toString(), cx, cy + tp.textSize / 3f, tp)
        }
    }
}

/** Magnet icon drawn with straight lines only: a squared U with two striped pole caps. */
class MagnetView(ctx: Context) : View(ctx) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()
    private var fg = UiKit.TEXT
    private var bgc = UiKit.CHIP

    /** on = filled (selected) chip: dark magnet on a white tile. */
    fun setOn(on: Boolean) {
        fg = if (on) UiKit.ON_ACCENT else UiKit.TEXT
        bgc = if (on) UiKit.ACCENT else UiKit.CHIP
        invalidate()
    }

    override fun onMeasure(w: Int, h: Int) {
        val s = UiKit.dp(context, 22)
        setMeasuredDimension(resolveSize(s, w), resolveSize(s, h))
    }

    override fun onDraw(c: Canvas) {
        val side = Math.min(width - paddingLeft - paddingRight, height - paddingTop - paddingBottom).toFloat()
        if (side <= 0f) return
        val ox = (width - side) / 2f
        val oy = (height - side) / 2f
        fun px(u: Float) = ox + u * side
        fun py(v: Float) = oy + v * side
        path.reset()
        path.moveTo(px(0.10f), py(0.06f)); path.lineTo(px(0.38f), py(0.06f)); path.lineTo(px(0.38f), py(0.56f))
        path.lineTo(px(0.62f), py(0.56f)); path.lineTo(px(0.62f), py(0.06f)); path.lineTo(px(0.90f), py(0.06f))
        path.lineTo(px(0.90f), py(0.94f)); path.lineTo(px(0.10f), py(0.94f)); path.close()
        p.style = Paint.Style.FILL
        p.color = fg
        c.drawPath(path, p)
        // pole caps: tile-coloured band with a thin frame, reads as the two magnet tips
        val capBottom = 0.30f
        p.color = bgc
        c.drawRect(px(0.10f), py(0.06f), px(0.38f), py(capBottom), p)
        c.drawRect(px(0.62f), py(0.06f), px(0.90f), py(capBottom), p)
        p.style = Paint.Style.STROKE
        p.strokeWidth = Math.max(1f, side * 0.06f)
        p.color = fg
        val i = p.strokeWidth / 2f
        c.drawRect(px(0.10f) + i, py(0.06f) + i, px(0.38f) - i, py(capBottom), p)
        c.drawRect(px(0.62f) + i, py(0.06f) + i, px(0.90f) - i, py(capBottom), p)
    }
}

/** Flat rectangular ON/OFF switch with a square knob. */
class SquareToggle(ctx: Context, private var on: Boolean, private val onChange: (Boolean) -> Unit) : View(ctx) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)

    init {
        setOnClickListener { on = !on; invalidate(); onChange(on) }
    }

    override fun onMeasure(w: Int, h: Int) {
        setMeasuredDimension(UiKit.dp(context, 46), UiKit.dp(context, 24))
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val b = UiKit.dp(context, 1).toFloat() + 0.5f
        p.style = Paint.Style.FILL
        p.color = if (on) UiKit.ACCENT else UiKit.CHIP
        c.drawRect(0f, 0f, w, h, p)
        p.style = Paint.Style.STROKE
        p.strokeWidth = b
        p.color = if (on) UiKit.ACCENT else UiKit.HAIR
        c.drawRect(b / 2f, b / 2f, w - b / 2f, h - b / 2f, p)
        val k = h - UiKit.dp(context, 8)
        val m = UiKit.dp(context, 4).toFloat()
        p.style = Paint.Style.FILL
        p.color = if (on) UiKit.ON_ACCENT else UiKit.MUTED
        val left = if (on) w - m - k else m
        c.drawRect(left, m, left + k, m + k, p)
    }
}
