package com.ndrx.mic

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView

/** Monochrome state markers drawn below each configured slot. */
class DotsView(ctx: Context) : View(ctx) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val tp = Paint(Paint.ANTI_ALIAS_FLAG)

    init {
        tp.color = Color.WHITE
        tp.textAlign = Paint.Align.CENTER
        tp.typeface = Typeface.DEFAULT_BOLD
        tp.textSize = UiKit.dp(ctx, 11).toFloat()
    }

    override fun onDraw(c: Canvas) {
        val loc = IntArray(2)
        getLocationOnScreen(loc)
        val sw = Engine.screenW
        val slots = Engine.slots
        val st = Engine.snapshot()
        val rad = UiKit.dp(context, 6).toFloat()
        for (i in slots.indices) {
            val s = slots[i]
            val cx = s.x * sw - loc[0]
            val cy = s.y * sw + s.r * sw * 1.3f - loc[1]
            p.color = when (st.getOrNull(i)) {
                Classifier.LOCKED -> UiKit.DANGER
                Classifier.EMPTY -> UiKit.ACCENT
                Classifier.OCC -> UiKit.BLUE
                else -> UiKit.YELLOW
            }
            c.drawCircle(cx, cy, rad, p)
            c.drawText((i + 1).toString(), cx + rad * 2.4f, cy + rad * 0.6f, tp)
        }
    }
}

/** Full-screen helper to place custom mic positions by tapping their centers. */
class EditorView(
    ctx: Context,
    private val onDone: (List<Slot>) -> Unit,
    private val onCancel: () -> Unit
) : FrameLayout(ctx) {
    private val pts = ArrayList<Slot>()
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val tp = Paint(Paint.ANTI_ALIAS_FLAG)
    private val sw: Float = Engine.screenW

    private val canvasView = object : View(ctx) {
        override fun onDraw(c: Canvas) { drawAll(c, this) }
        override fun onTouchEvent(e: MotionEvent): Boolean {
            if (e.actionMasked == MotionEvent.ACTION_DOWN) {
                tap(e.rawX / sw, e.rawY / sw)
                invalidate()
            }
            return true
        }
    }

    init {
        tp.color = Color.WHITE
        tp.textAlign = Paint.Align.CENTER
        tp.typeface = Typeface.DEFAULT_BOLD
        tp.textSize = UiKit.dp(ctx, 16).toFloat()
        addView(canvasView, LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        val bar = LinearLayout(ctx)
        bar.orientation = LinearLayout.HORIZONTAL
        bar.gravity = Gravity.CENTER
        bar.setBackgroundColor(0xE60A0A0A.toInt())
        bar.setPadding(UiKit.dp(ctx, 8), UiKit.dp(ctx, 8), UiKit.dp(ctx, 8), UiKit.dp(ctx, 8))
        fun b(text: Int, bgc: Int, fg: Int, f: () -> Unit) {
            val t = UiKit.tv(ctx, ctx.getString(text), 14f, fg, true)
            t.gravity = Gravity.CENTER
            t.setPadding(UiKit.dp(ctx, 8), UiKit.dp(ctx, 10), UiKit.dp(ctx, 8), UiKit.dp(ctx, 10))
            t.background = UiKit.bg(ctx, bgc, 10)
            t.setOnClickListener { f() }
            val lp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            lp.setMargins(UiKit.dp(ctx, 3), 0, UiKit.dp(ctx, 3), 0)
            bar.addView(t, lp)
        }
        b(R.string.ed_undo, UiKit.SURFACE_ALT, UiKit.TEXT) { if (pts.isNotEmpty()) pts.removeAt(pts.size - 1); canvasView.invalidate() }
        b(R.string.ed_clear, UiKit.SURFACE_ALT, UiKit.TEXT) { pts.clear(); canvasView.invalidate() }
        b(R.string.ed_cancel, UiKit.SURFACE_ALT, UiKit.TEXT) { onCancel() }
        b(R.string.ed_done, UiKit.ACCENT, UiKit.BLACK) { onDone(Layouts.sortReading(pts)) }
        val lp = LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.gravity = Gravity.BOTTOM
        lp.bottomMargin = UiKit.dp(ctx, 56)
        addView(bar, lp)
    }

    private fun tap(ux: Float, uy: Float) {
        for (i in pts.indices) {
            val s = pts[i]
            val dx = s.x - ux
            val dy = s.y - uy
            if (Math.sqrt((dx * dx + dy * dy).toDouble()) < s.r * 0.8) { pts.removeAt(i); return }
        }
        pts.add(Slot(ux, uy, 0.0694f))
    }

    private fun drawAll(c: Canvas, v: View) {
        val loc = IntArray(2)
        v.getLocationOnScreen(loc)
        c.drawColor(0x66000000)
        val sorted = Layouts.sortReading(pts)
        for (i in sorted.indices) {
            val s = sorted[i]
            val cx = s.x * sw - loc[0]
            val cy = s.y * sw - loc[1]
            p.style = Paint.Style.FILL
            p.color = 0x55444444
            c.drawCircle(cx, cy, s.r * sw, p)
            p.style = Paint.Style.STROKE
            p.strokeWidth = UiKit.dp(context, 2).toFloat()
            p.color = UiKit.ACCENT
            c.drawCircle(cx, cy, s.r * sw, p)
            c.drawText((i + 1).toString(), cx, cy + tp.textSize / 3f, tp)
        }
        tp.textSize = UiKit.dp(context, 15).toFloat()
        c.drawText(context.getString(R.string.ed_hint), v.width / 2f, UiKit.dp(context, 90).toFloat(), tp)
        tp.textSize = UiKit.dp(context, 16).toFloat()
    }
}

/** Mini schematic of a layout, used in the layout picker. */
class LayoutPreview(ctx: Context, private val slots: List<Slot>, private val sel: Boolean) : View(ctx) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val tp = Paint(Paint.ANTI_ALIAS_FLAG)

    init {
        tp.color = Color.WHITE
        tp.textAlign = Paint.Align.CENTER
        tp.typeface = Typeface.DEFAULT_BOLD
    }

    override fun onDraw(c: Canvas) {
        if (slots.isEmpty()) {
            tp.textSize = UiKit.dp(context, 28).toFloat()
            c.drawText("?", width / 2f, height / 2f + tp.textSize / 3f, tp)
            return
        }
        val minX = slots.minOf { it.x - it.r }
        val maxX = slots.maxOf { it.x + it.r }
        val minY = slots.minOf { it.y - it.r }
        val maxY = slots.maxOf { it.y + it.r }
        val pad = UiKit.dp(context, 6).toFloat()
        val sc = Math.min((width - 2 * pad) / (maxX - minX), (height - 2 * pad) / (maxY - minY))
        val ox = (width - (maxX - minX) * sc) / 2f - minX * sc
        val oy = (height - (maxY - minY) * sc) / 2f - minY * sc
        for (i in slots.indices) {
            val s = slots[i]
            val cx = ox + s.x * sc
            val cy = oy + s.y * sc
            val r = s.r * sc
            p.style = Paint.Style.FILL
            p.color = if (s.host) UiKit.SURFACE_ALT else UiKit.ACCENT_DIM
            c.drawCircle(cx, cy, r, p)
            p.style = Paint.Style.STROKE
            p.strokeWidth = UiKit.dp(context, 1).toFloat()
            p.color = if (sel) UiKit.ACCENT else UiKit.STROKE
            c.drawCircle(cx, cy, r, p)
            tp.textSize = r * 0.95f
            c.drawText((i + 1).toString(), cx, cy + tp.textSize / 3f, tp)
        }
    }
}
