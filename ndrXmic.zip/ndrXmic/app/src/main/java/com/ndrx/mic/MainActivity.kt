package com.ndrx.mic

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.Color
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private val REQ = 100
    private var scroll: ScrollView? = null

    private fun d(v: Int) = UiKit.dp(this, v)

    override fun attachBaseContext(newBase: Context) {
        super.attachBaseContext(Loc.wrap(newBase))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Engine.load()
        window.statusBarColor = UiKit.BG
        window.navigationBarColor = UiKit.BG
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) requestPermissions(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), 1)
        build()
        handleIntent(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIntent(intent)
    }

    override fun onResume() {
        super.onResume()
        build()
    }

    private fun handleIntent(i: Intent?) {
        if (i != null && i.getBooleanExtra("capture", false)) {
            i.removeExtra("capture")
            requestCapture()
        }
    }

    // ---------------------------------------------------------------- capture
    private fun requestCapture() {
        val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        startActivityForResult(mpm.createScreenCaptureIntent(), REQ)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ) {
            if (resultCode == RESULT_OK && data != null) {
                val i = Intent(this, CaptureService::class.java)
                i.putExtra("code", resultCode)
                i.putExtra("data", data)
                startForegroundService(i)
                ClickService.instance?.showPanel()
                moveTaskToBack(true)
            } else {
                Toast.makeText(this, R.string.capture_denied, Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun onStart2() {
        val svc = ClickService.instance
        if (svc == null) {
            Toast.makeText(this, R.string.need_access, Toast.LENGTH_SHORT).show()
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            return
        }
        if ((Engine.mode == Engine.PAD && Prefs.layoutId != "auto" && !Prefs.autoConfirm) || Engine.capturing) {
            svc.showPanel()
            moveTaskToBack(true)
        } else requestCapture()
    }

    private fun onStop2() {
        stopService(Intent(this, CaptureService::class.java))
        Engine.capturing = false
        ClickService.instance?.hidePanel()
        window.decorView.postDelayed({ build() }, 250)
    }

    // ---------------------------------------------------------------- UI
    private fun changed() {
        Engine.load()
        ClickService.instance?.refreshUi()
        build()
    }

    private fun build() {
        val y = scroll?.scrollY ?: 0
        val sv = ScrollView(this)
        sv.setBackgroundColor(UiKit.BG)
        sv.layoutDirection = if (Loc.isAr()) View.LAYOUT_DIRECTION_RTL else View.LAYOUT_DIRECTION_LTR
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(d(16), d(20), d(16), d(32))
        sv.addView(col)

        header(col)
        setupCard(col)
        modeCard(col)
        layoutCard(col)
        optionsCard(col)
        startArea(col)
        val f = UiKit.tv(this, getString(R.string.footer), 12f, UiKit.MUTED)
        f.setPadding(d(4), d(16), d(4), 0)
        col.addView(f)

        setContentView(sv)
        scroll = sv
        sv.post { sv.scrollTo(0, y) }
    }

    private fun header(col: LinearLayout) {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        val logo = ImageView(this)
        logo.setImageResource(R.drawable.logo)
        row.addView(logo, LinearLayout.LayoutParams(d(76), d(76)))
        val tcol = LinearLayout(this)
        tcol.orientation = LinearLayout.VERTICAL
        tcol.setPadding(d(12), 0, d(12), 0)
        tcol.addView(UiKit.tv(this, "ndrXmic", 28f, UiKit.ACCENT, true, true))
        tcol.addView(UiKit.tv(this, getString(R.string.tagline), 12f, UiKit.MUTED))
        row.addView(tcol, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val lang = UiKit.tv(this, getString(R.string.lang_switch), 13f, UiKit.TEXT, true)
        lang.setPadding(d(12), d(8), d(12), d(8))
        lang.background = UiKit.bg(this, UiKit.CARD, 10, UiKit.STROKE, 1)
        lang.setOnClickListener {
            Prefs.lang = if (Loc.isAr()) "en" else "ar"
            recreate()
        }
        row.addView(lang)
        col.addView(row)
    }

    private fun card(col: LinearLayout, title: String): LinearLayout {
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        c.background = UiKit.bg(this, UiKit.CARD, 16, UiKit.STROKE, 1)
        c.setPadding(d(14), d(12), d(14), d(14))
        c.addView(UiKit.tv(this, title, 14f, UiKit.ACCENT, true, true))
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.topMargin = d(16)
        col.addView(c, lp)
        return c
    }

    private fun btn(text: String, filled: Boolean, onClick: () -> Unit): TextView {
        val t = UiKit.tv(this, text, 14f, if (filled) Color.WHITE else UiKit.TEXT, true)
        t.gravity = Gravity.CENTER
        t.setPadding(d(14), d(11), d(14), d(11))
        t.background = if (filled) UiKit.bg(this, UiKit.ACCENT, 12) else UiKit.bg(this, 0xFF22100F.toInt(), 12, UiKit.STROKE, 1)
        t.setOnClickListener { onClick() }
        return t
    }

    private fun setupCard(col: LinearLayout) {
        val c = card(col, getString(R.string.sec_setup))
        val on = ClickService.instance != null
        val st = UiKit.tv(this, getString(if (on) R.string.access_on else R.string.access_off), 14f,
            if (on) UiKit.ACCENT else UiKit.DANGER, true)
        st.setPadding(0, d(10), 0, d(10))
        c.addView(st)
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        val a = btn(getString(R.string.access_btn), true) { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        val b = btn(getString(R.string.appinfo_btn), false) {
            startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
        }
        val l1 = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        l1.marginEnd = d(6)
        row.addView(a, l1)
        row.addView(b, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        c.addView(row)
        if (!on) {
            val h = UiKit.tv(this, getString(R.string.restricted_hint), 12f, UiKit.MUTED)
            h.setPadding(0, d(10), 0, 0)
            c.addView(h)
        }
    }

    private fun modeCard(col: LinearLayout) {
        val c = card(col, getString(R.string.sec_mode))
        val titles = intArrayOf(R.string.mode_open, R.string.mode_follow, R.string.mode_pad, R.string.mode_watch)
        val descs = intArrayOf(R.string.mode_open_d, R.string.mode_follow_d, R.string.mode_pad_d, R.string.mode_watch_d)
        for (i in 0..3) {
            val sel = Prefs.mode == i
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER_VERTICAL
            row.setPadding(d(12), d(10), d(12), d(10))
            row.background = UiKit.bg(this, if (sel) UiKit.ACCENT_DIM else UiKit.BG, 12, if (sel) UiKit.ACCENT else UiKit.STROKE, 1)
            val dot = TextView(this)
            dot.text = if (sel) "●" else "○"
            dot.setTextColor(if (sel) UiKit.ACCENT else UiKit.MUTED)
            dot.textSize = 18f
            row.addView(dot)
            val tx = LinearLayout(this)
            tx.orientation = LinearLayout.VERTICAL
            tx.setPadding(d(10), 0, d(4), 0)
            tx.addView(UiKit.tv(this, getString(titles[i]), 15f, UiKit.TEXT, true))
            tx.addView(UiKit.tv(this, getString(descs[i]), 12f, UiKit.MUTED))
            row.addView(tx, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            row.setOnClickListener { Prefs.mode = i; changed() }
            val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            lp.topMargin = d(10)
            c.addView(row, lp)
        }
    }

    private fun layoutCard(col: LinearLayout) {
        val c = card(col, getString(R.string.sec_layout))
        val all = Layouts.all()
        val cur = Prefs.layoutId
        var i = 0
        while (i < all.size) {
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            for (k in 0..1) {
                val idx = i + k
                if (idx >= all.size) {
                    row.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f))
                    continue
                }
                val l = all[idx]
                val sel = cur == l.id
                val cell = LinearLayout(this)
                cell.orientation = LinearLayout.VERTICAL
                cell.gravity = Gravity.CENTER_HORIZONTAL
                cell.setPadding(d(6), d(6), d(6), d(8))
                cell.background = UiKit.bg(this, if (sel) UiKit.ACCENT_DIM else UiKit.BG, 12, if (sel) UiKit.ACCENT else UiKit.STROKE, 1)
                if (l.id == "auto") {
                    val at = UiKit.tv(this, "⚡ AUTO", 20f, if (sel) UiKit.ACCENT else UiKit.TEXT, true, true)
                    at.gravity = Gravity.CENTER
                    cell.addView(at, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, d(104)))
                } else
                cell.addView(LayoutPreview(this, l.slots, sel), LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, d(104)))
                val name = UiKit.tv(this, getString(l.nameRes), 12f, if (sel) UiKit.ACCENT else UiKit.TEXT, true)
                name.gravity = Gravity.CENTER
                name.setPadding(0, d(4), 0, 0)
                cell.addView(name)
                cell.setOnClickListener { Prefs.layoutId = l.id; changed() }
                val lp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
                lp.setMargins(d(4), d(4), d(4), d(4))
                row.addView(cell, lp)
            }
            c.addView(row)
            i += 2
        }
        if (Prefs.layoutId == "auto") {
            val dn = Layouts.current()
            val dt = UiKit.tv(this, getString(R.string.auto_now, getString(dn.nameRes)), 13f, UiKit.ACCENT, true)
            dt.setPadding(d(4), d(8), d(4), 0)
            c.addView(dt)
        }
        val h = UiKit.tv(this, getString(R.string.custom_hint), 12f, UiKit.MUTED)
        h.setPadding(d(4), d(8), d(4), 0)
        c.addView(h)
    }

    private fun segmented(labels: List<String>, sel: Int, onSel: (Int) -> Unit): LinearLayout {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.background = UiKit.bg(this, UiKit.BG, 10, UiKit.STROKE, 1)
        row.setPadding(d(2), d(2), d(2), d(2))
        for (i in labels.indices) {
            val t = UiKit.tv(this, labels[i], 13f, if (i == sel) Color.WHITE else UiKit.TEXT, true)
            t.gravity = Gravity.CENTER
            t.setPadding(d(6), d(9), d(6), d(9))
            if (i == sel) t.background = UiKit.bg(this, UiKit.ACCENT, 8)
            t.setOnClickListener { onSel(i) }
            row.addView(t, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        }
        return row
    }

    private fun labeled(c: LinearLayout, label: String, w: View) {
        val t = UiKit.tv(this, label, 13f, UiKit.TEXT)
        t.setPadding(0, d(14), 0, d(6))
        c.addView(t)
        c.addView(w)
    }

    private fun switchRow(c: LinearLayout, label: String, on: Boolean, onChange: (Boolean) -> Unit) {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.setPadding(0, d(10), 0, 0)
        row.addView(UiKit.tv(this, label, 13f, UiKit.TEXT), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val sw = Switch(this)
        sw.isChecked = on
        val states = arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf())
        sw.thumbTintList = ColorStateList(states, intArrayOf(UiKit.ACCENT, 0xFFA08489.toInt()))
        sw.trackTintList = ColorStateList(states, intArrayOf(0xFF8A1220.toInt(), 0xFF2B1416.toInt()))
        sw.setOnCheckedChangeListener { _, v -> onChange(v) }
        row.addView(sw)
        c.addView(row)
    }

    private fun optionsCard(col: LinearLayout) {
        val c = card(col, getString(R.string.sec_options))
        labeled(c, getString(R.string.opt_sens),
            segmented(listOf(getString(R.string.sens_fast), getString(R.string.sens_normal), getString(R.string.sens_safe)),
                (Prefs.confirm - 1).coerceIn(0, 2)) { Prefs.confirm = it + 1; changed() })
        val cds = intArrayOf(1000, 3000, 5000, 8000)
        labeled(c, getString(R.string.opt_cool),
            segmented(listOf("1s", "3s", "5s", "8s"), cds.indexOf(Prefs.cooldown).coerceAtLeast(0)) { Prefs.cooldown = cds[it]; changed() })
        labeled(c, getString(R.string.opt_pad),
            segmented(listOf(getString(R.string.size_s), getString(R.string.size_m), getString(R.string.size_l)),
                Prefs.padSize.coerceIn(0, 2)) { Prefs.padSize = it; changed() })
        switchRow(c, getString(R.string.opt_confirm), Prefs.autoConfirm) { Prefs.autoConfirm = it; Engine.load() }
        switchRow(c, getString(R.string.opt_retry), Prefs.retry) { Prefs.retry = it; Engine.load() }
        switchRow(c, getString(R.string.opt_double), Prefs.doubleTap) { Prefs.doubleTap = it; Engine.load() }
        switchRow(c, getString(R.string.opt_dots), Prefs.dots) { Prefs.dots = it; ClickService.instance?.refreshUi() }
    }

    private fun startArea(col: LinearLayout) {
        val running = ClickService.instance?.panelVisible == true
        val b = btn(getString(if (running) R.string.btn_stop else R.string.btn_start), !running) {
            if (running) onStop2() else onStart2()
        }
        b.textSize = 18f
        b.setPadding(d(14), d(16), d(14), d(16))
        if (running) b.setTextColor(UiKit.DANGER)
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.topMargin = d(20)
        col.addView(b, lp)
        if (running) {
            val t = UiKit.tv(this, getString(R.string.running), 12f, UiKit.MUTED)
            t.gravity = Gravity.CENTER
            t.setPadding(0, d(8), 0, 0)
            col.addView(t)
        }
    }
}
