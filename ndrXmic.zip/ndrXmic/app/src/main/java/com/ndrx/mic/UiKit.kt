package com.ndrx.mic

import android.content.Context
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.StateListDrawable
import android.util.TypedValue
import android.widget.TextView

object UiKit {
    val BG = 0xFF090405.toInt()
    val CARD = 0xFF150A0C.toInt()
    val STROKE = 0xFF3A1217.toInt()
    val ACCENT = 0xFFFF2A3D.toInt()
    val ACCENT_DIM = 0xFF4A0F16.toInt()
    val TEXT = 0xFFF4E8EA.toInt()
    val MUTED = 0xFFA08489.toInt()
    val DANGER = 0xFFFFA11F.toInt()
    val BLUE = 0xFFFF5C6C.toInt()
    val YELLOW = 0xFFFFB347.toInt()

    fun dp(c: Context, v: Int): Int = (v * c.resources.displayMetrics.density + 0.5f).toInt()

    fun bg(c: Context, color: Int, rDp: Int, stroke: Int = 0, strokeDp: Int = 0): GradientDrawable {
        val g = GradientDrawable()
        g.setColor(color)
        g.cornerRadius = dp(c, rDp).toFloat()
        if (strokeDp > 0) g.setStroke(dp(c, strokeDp), stroke)
        return g
    }

    fun pressable(normal: Drawable, pressed: Drawable): StateListDrawable {
        val s = StateListDrawable()
        s.addState(intArrayOf(android.R.attr.state_pressed), pressed)
        s.addState(intArrayOf(), normal)
        return s
    }

    fun tv(c: Context, text: String, sp: Float, color: Int, bold: Boolean = false, mono: Boolean = false): TextView {
        val t = TextView(c)
        t.text = text
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp)
        t.setTextColor(color)
        t.typeface = when {
            mono -> Typeface.create(Typeface.MONOSPACE, if (bold) Typeface.BOLD else Typeface.NORMAL)
            bold -> Typeface.DEFAULT_BOLD
            else -> Typeface.DEFAULT
        }
        return t
    }
}
