package com.ndrx.mic

import android.content.Context
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.StateListDrawable
import android.util.TypedValue
import android.widget.TextView

/** Monochrome, high-contrast UI tokens. */
object UiKit {
    val BG = 0xFF050505.toInt()
    val CARD = 0xFF111111.toInt()
    val STROKE = 0xFF777777.toInt()
    val ACCENT = 0xFFFFFFFF.toInt()
    val ACCENT_DIM = 0xFF242424.toInt()
    val TEXT = 0xFFF5F5F5.toInt()
    val MUTED = 0xFFAAAAAA.toInt()
    val DANGER = 0xFF9A9A9A.toInt()
    val BLUE = 0xFF777777.toInt()
    val YELLOW = 0xFFCCCCCC.toInt()
    val SURFACE_ALT = 0xFF1C1C1C.toInt()
    val BLACK = 0xFF000000.toInt()

    fun dp(c: Context, v: Int): Int = (v * c.resources.displayMetrics.density + 0.5f).toInt()

    /** UI surfaces intentionally use square corners for the NMic Pro geometric style. */
    fun bg(c: Context, color: Int, rDp: Int, stroke: Int = 0, strokeDp: Int = 0): GradientDrawable {
        val g = GradientDrawable()
        g.setColor(color)
        g.cornerRadius = 0f
        if (strokeDp > 0) g.setStroke(dp(c, strokeDp), stroke)
        return g
    }

    fun pressable(normal: Drawable, pressed: Drawable): StateListDrawable {
        val s = StateListDrawable()
        s.addState(intArrayOf(android.R.attr.state_pressed), pressed)
        s.addState(intArrayOf(), normal)
        return s
    }

    fun tv(c: Context, text: String, sp: Float, color: Int, bold: Boolean = false, mono: Boolean = false): TextView {
        val t = TextView(c)
        t.text = text
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp)
        t.setTextColor(color)
        t.typeface = when {
            mono -> Typeface.create(if (bold) "sans-serif-black" else "sans-serif", if (bold) Typeface.BOLD else Typeface.NORMAL)
            bold -> Typeface.create("sans-serif", Typeface.BOLD)
            else -> Typeface.create("sans-serif", Typeface.NORMAL)
        }
        return t
    }
}
