package com.ndrx.mic

/**
 * Finds the two pop-ups the game shows after a seat tap and tells where to press:
 *  - the "Confirm / Cancel" switch-seat dialog  -> the yellow Confirm button
 *  - the "Take mic / Lock mic / Invite" menu    -> the first row (Take mic)
 * Returned coordinates are frame pixels.
 */
object Popup {
    /** Turbo: accept the pop-up while it is still fading in, so the tap lands a few frames earlier. */
    @JvmField var relaxed = true

    class Hit(val x: Float, val y: Float, val menu: Boolean)

    private fun yellow(c: Int): Boolean {
        val r = (c shr 16) and 255; val g = (c shr 8) and 255; val b = c and 255
        if (relaxed) return r > 205 && g > 140 && g < 248 && b < 145 && r - b > 100 && r >= g
        return r > 215 && g > 150 && g < 245 && b < 130 && r - b > 110 && r >= g
    }

    private fun mint(c: Int): Boolean {
        val r = (c shr 16) and 255; val g = (c shr 8) and 255; val b = c and 255
        if (relaxed) return g > 222 && b > 208 && r in 185..250 && g - r > 6
        return g > 232 && b > 220 && r in 195..248 && g - r > 8
    }

    private fun green(c: Int): Boolean {
        val r = (c shr 16) and 255; val g = (c shr 8) and 255; val b = c and 255
        return g > 135 && r < 125 && g - r > 55 && b in 81..199
    }

    fun find(f: Frame): Hit? = findConfirm(f) ?: findMenu(f)

    fun findConfirm(f: Frame): Hit? {
        val w = f.w; val h = f.h
        val s = Math.max(3, w / 200)
        val gw = w / s; val gh = h / s
        val y0 = (0.3f * h).toInt() / s; val y1 = Math.min(gh, (0.9f * h).toInt() / s)
        if (y1 <= y0) return null
        val m = BooleanArray(gw * gh)
        var any = 0
        for (gy in y0 until y1) for (gx in 0 until gw) {
            if (yellow(f.rgb(gx * s, gy * s))) { m[gy * gw + gx] = true; any++ }
        }
        if (any < 40) return null
        val seen = BooleanArray(gw * gh)
        val st = IntArray(gw * gh)
        for (gy in y0 until y1) for (gx in 0 until gw) {
            val i0 = gy * gw + gx
            if (!m[i0] || seen[i0]) continue
            var sp = 0
            st[sp++] = i0; seen[i0] = true
            var cnt = 0; var mnx = gx; var mxx = gx; var mny = gy; var mxy = gy
            while (sp > 0) {
                val cur = st[--sp]
                val cy = cur / gw; val cx = cur % gw
                cnt++
                if (cx < mnx) mnx = cx; if (cx > mxx) mxx = cx
                if (cy < mny) mny = cy; if (cy > mxy) mxy = cy
                if (cy + 1 < gh) { val n = cur + gw; if (m[n] && !seen[n]) { seen[n] = true; st[sp++] = n } }
                if (cy > 0) { val n = cur - gw; if (m[n] && !seen[n]) { seen[n] = true; st[sp++] = n } }
                if (cx + 1 < gw) { val n = cur + 1; if (m[n] && !seen[n]) { seen[n] = true; st[sp++] = n } }
                if (cx > 0) { val n = cur - 1; if (m[n] && !seen[n]) { seen[n] = true; st[sp++] = n } }
            }
            val bw = (mxx - mnx + 1) * s; val bh = (mxy - mny + 1) * s
            val fill = cnt.toFloat() / ((mxx - mnx + 1) * (mxy - mny + 1))
            if (bw < 0.17f * w || bw > 0.45f * w || bh < 0.045f * w || bh > 0.17f * w || fill < 0.45f) continue
            val px = mnx * s; val qx = (mxx + 1) * s; val py = mny * s
            val d = (0.03f * w).toInt(); val e = (0.02f * w).toInt()
            if (mint(f.rgb(px + e, py - d)) || mint(f.rgb(qx - e, py - d))) {
                return Hit((px + qx) / 2f, (py + (mxy + 1) * s) / 2f, false)
            }
        }
        return null
    }

    private fun run(f: Frame, x: Int, out: IntArray) {
        val gap = Math.max(2, (0.012f * f.w).toInt())
        var start = -1; var last = -1; var bs = 0; var be = 0
        for (y in (0.15f * f.h).toInt() until (0.95f * f.h).toInt()) {
            if (mint(f.rgb(x, y))) {
                if (start < 0 || y - last > gap) start = y
                last = y
                if (last - start > be - bs) { bs = start; be = last }
            }
        }
        out[0] = bs; out[1] = be
    }

    private fun findMenu(f: Frame): Hit? {
        val w = f.w
        val a = IntArray(2); val b = IntArray(2)
        run(f, (0.2f * w).toInt(), a)
        run(f, (0.85f * w).toInt(), b)
        if (Math.abs(a[0] - b[0]) > 0.02f * w || a[1] - a[0] < 0.25f * w) return null
        val cy = a[0] + (0.09f * w).toInt()
        // the first row has a green icon on one side and a green label: look for either, anywhere on the row
        var ok = false
        var xx = 0.46f
        while (xx <= 0.84f) {
            if (green(f.rgb((xx * w).toInt(), cy))) { ok = true; break }
            xx += 0.02f
        }
        if (!ok) return null
        return Hit(0.5f * w, cy.toFloat(), true)
    }
}
