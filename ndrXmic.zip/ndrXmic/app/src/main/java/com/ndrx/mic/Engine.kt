package com.ndrx.mic

import android.os.Handler
import android.os.HandlerThread
import android.os.Looper
import android.os.Process
import android.os.SystemClock
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Reads the mic seats from every captured frame and decides when to tap.
 * Modes: OPEN (catch a mic the instant it opens), FOLLOW, PAD (manual numbers),
 * WATCH (take over a seat the moment its owner leaves) and MAGNET (shadow one person:
 * leave the mic when he leaves, go back up when he comes back).
 */
object Engine {
    const val OPEN = 0
    const val FOLLOW = 1
    const val PAD = 2
    const val WATCH = 3
    const val MAGNET = 4

    @Volatile var mode = OPEN
    @Volatile var armed = false
    @Volatile var capturing = false
    @Volatile var screenW = 1080f
    @Volatile var frameW = 0
    @Volatile var currentId = ""

    @Volatile var slots: List<Slot> = emptyList()
        private set
    var onStatus: ((String) -> Unit)? = null

    // ---- magnet state shown by the UI
    // ---- focus ("Rasd"): act on one seat only, with any mode
    @Volatile var focus = -1
        private set
    @Volatile var focusPick = false

    @Volatile var mgTarget = -1
        private set
    @Volatile var mgMe = -1
        private set
    @Volatile var mgPhase = 0          // 0 = target is on a mic, 1 = target is away
        private set

    private val lock = Any()
    private val main = Handler(Looper.getMainLooper())

    // ---- layout + calibration
    private var base: List<Slot> = emptyList()
    private var rowIdx = IntArray(0)
    private var calDy = FloatArray(0)
    private var calXs = FloatArray(0)      // per-row horizontal spacing scale (around the screen centre)
    private var calDx = FloatArray(0)      // per-row horizontal shift
    private var rowDone = BooleanArray(0)
    private var calK = 1f
    private var calNudge = 0f
    private var calOn = true

    // ---- per-seat reading state
    private var raw = IntArray(0)
    private var stable = IntArray(0)
    private var cand = IntArray(0)
    private var candN = IntArray(0)
    private var offs: Array<IntArray> = emptyArray()
    private var aligned = BooleanArray(0)
    private var lastDeep = LongArray(0)
    private var watchUntil = LongArray(0)
    private var lastSig = LongArray(0)

    // ---- settings
    private var cooldownUntil = 0L
    private var confirm = 1
    private var cooldown = 3000
    private var retry = true
    private var dbl = false
    private var auto = false
    private var autoConfirm = true
    private var lastMaint = 0L
    private var lastDet = 0L
    private var lastCal = 0L
    private var pendId: String? = null
    private var pendN = 0

    // ---- heavy work (auto-detect / fitting / smart scan) runs on its own low-priority thread,
    //      so the capture thread only ever does the cheap read + tap path.
    private val worker: Handler by lazy {
        val t = HandlerThread("ndrx-fit", Process.THREAD_PRIORITY_BACKGROUND)
        t.start()
        Handler(t.looper)
    }
    private val workBusy = AtomicBoolean(false)
    private var jobFrame: Frame? = null
    private var lastScan = 0L
    private var lastVerify = 0L
    private var detectFails = 0
    @Volatile private var scanNow = false

    // ---- pop-ups after a seat tap
    @Volatile private var popupUntil = 0L
    @Volatile private var popupAt = 0L
    @Volatile private var confirmOnly = false

    // ---- magnet internals
    private var mgSig: IntArray? = null
    private var mgSigPending = false
    private var mgLeftAt = 0L
    private var mgLastMe = -1
    private var mgWantUp = false
    private var mgWantAt = 0L
    private var mgBusyUntil = 0L
    private var mgExitSeat = -1
    private var mgExitAt = 0L
    private var mgExitTries = 0
    private var mgTakeSeat = -1
    private var mgTakeAt = 0L
    private var mgTakeTries = 0

    // ------------------------------------------------------------------ setup
    fun load() {
        mode = Prefs.mode
        Classifier.turbo = Prefs.turbo
        Classifier.deep = Prefs.deep
        Popup.relaxed = Prefs.turbo
        confirm = if (Prefs.turbo) 1 else Prefs.confirm
        cooldown = Prefs.cooldown
        retry = Prefs.retry
        dbl = Prefs.doubleTap
        autoConfirm = Prefs.autoConfirm
        auto = Prefs.layoutId == "auto"
        pendId = null; pendN = 0
        val m = App.ctx.resources.displayMetrics
        screenW = Math.min(m.widthPixels, m.heightPixels).toFloat()
        // the smart scan is only a fallback: it stays until a known preset matches the screen again
        if (auto && currentId == "smart" && base.isNotEmpty()) return
        val l = Layouts.current()
        if (l.id == currentId && l.slots == base && base.isNotEmpty()) return
        setLayout(l)
    }

    /** Re-fits the layout from scratch on the next frame (reset calibration, detect the preset, re-measure). */
    fun requestScan() { scanNow = true }

    fun setFocus(i: Int) {
        if (i >= 0 && i < slots.size) focus = i
        focusPick = false
    }

    fun clearFocus() { focus = -1; focusPick = false }

    private fun okSeat(i: Int): Boolean = focus < 0 || i == focus

    private fun setLayout(l: Layout) {
        synchronized(lock) {
            currentId = l.id
            focus = -1
            focusPick = false
            base = l.slots
            calOn = l.id != "custom" && l.id != "smart"
            val rows = Layouts.rowsOf(base)
            rowIdx = IntArray(base.size)
            for (r in rows.indices) {
                for (i in rows[r]) rowIdx[i] = r
            }
            loadCal(l.id, rows.size)
            rebuild()
            val n = base.size
            raw = IntArray(n) { Classifier.UNK }
            stable = IntArray(n) { -1 }
            cand = IntArray(n) { -1 }
            candN = IntArray(n)
            offs = Array(n) { IntArray(2) }
            aligned = BooleanArray(n)
            lastDeep = LongArray(n)
            watchUntil = LongArray(n)
            lastSig = LongArray(n)
            mgReset()
        }
    }

    private fun resetCal(rows: Int) {
        calK = 1f
        calNudge = 0f
        calDy = FloatArray(rows)
        calXs = FloatArray(rows) { 1f }
        calDx = FloatArray(rows)
        rowDone = BooleanArray(rows)
    }

    private fun loadCal(id: String, rows: Int) {
        resetCal(rows)
        if (id == "smart" || id == "custom") return
        val s = Prefs.calGet(id)
        if (s.isBlank()) return
        try {
            val p = s.split(";")
            val k = p[0].toFloat()
            val dys = p[1].split(",")
            val mask = p[2]
            val nu = p[3].toFloat()
            val xss = if (p.size > 4) p[4].split(",") else emptyList()
            val dxs = if (p.size > 5) p[5].split(",") else emptyList()
            for (r in 0 until rows) {
                if (r < dys.size && dys[r].isNotEmpty()) calDy[r] = dys[r].toFloat()
                if (r < xss.size && xss[r].isNotEmpty()) calXs[r] = xss[r].toFloat().coerceIn(0.8f, 1.25f)
                if (r < dxs.size && dxs[r].isNotEmpty()) calDx[r] = dxs[r].toFloat().coerceIn(-0.06f, 0.06f)
                rowDone[r] = r < mask.length && mask[r] == '1'
            }
            calK = k
            calNudge = nu
        } catch (_: Exception) {
            resetCal(rows)
        }
    }

    private fun saveCal() {
        if (!calOn || currentId == "smart") return
        val sb = StringBuilder()
        sb.append(calK).append(';')
        sb.append(calDy.joinToString(",")).append(';')
        for (b in rowDone) sb.append(if (b) '1' else '0')
        sb.append(';').append(calNudge)
        sb.append(';').append(calXs.joinToString(","))
        sb.append(';').append(calDx.joinToString(","))
        Prefs.calSet(currentId, sb.toString())
    }

    /**
     * Applies calibration on top of the preset geometry: row shift (up/down), seat scale,
     * horizontal spacing + shift per row and the manual nudge. The seat ORDER never changes:
     * seat #n of the preset is always seat #n, only its position on screen is corrected.
     */
    private fun rebuild() {
        val n = base.size
        val out = ArrayList<Slot>(n)
        for (i in 0 until n) {
            val s = base[i]
            if (!calOn) { out.add(s); continue }
            val r = rowIdx[i]
            val dy = (if (r < calDy.size) calDy[r] else 0f) + calNudge
            val xs = if (r < calXs.size) calXs[r] else 1f
            val dx = if (r < calDx.size) calDx[r] else 0f
            val x = if (s.host) s.x else 0.5f + (s.x - 0.5f) * xs + dx
            out.add(Slot(x, s.y + dy, s.r * calK, s.host))
        }
        slots = out
    }

    /** Manual fine-tune of every dot, in W units (positive = down). */
    fun nudge(dyW: Float) {
        synchronized(lock) {
            if (!calOn) return
            calNudge += dyW
            rebuild()
            saveCal()
        }
    }

    fun snapshot(): IntArray = synchronized(lock) { raw.copyOf() }

    private fun status(s: String) { onStatus?.invoke(s) }

    private fun say(id: Int, vararg a: Any) {
        // resolving a localized string builds a Context: keep that off the capture thread
        main.post { try { status(Loc.wrap(App.ctx).getString(id, *a)) } catch (_: Exception) {} }
    }

    // ------------------------------------------------------------------ per-frame entry
    fun onFrame(f: Frame) {
        try { run(f) } catch (_: Throwable) {}
    }

    private fun run(f: Frame) {
        val now = SystemClock.uptimeMillis()
        frameW = f.w

        // 1. pop-ups that follow a seat tap (Take mic / Exit mic / Confirm)
        if (now < popupUntil) {
            val h = if (confirmOnly) Popup.findConfirm(f) else Popup.find(f)
            if (h != null) {
                if (h.menu) { popupUntil = now + 1500L; confirmOnly = true } else { popupUntil = 0L; confirmOnly = false }
                popupAt = now
                val k = screenW / f.w
                ClickService.instance?.tap(h.x * k, h.y * k, false)
            }
        }

        // 2. layout auto-detect + row calibration (cheap, throttled)
        maintain(f, now)
        if (mode == PAD) return

        // 3. read the seats and react
        synchronized(lock) {
            val n = slots.size
            if (n == 0) return
            val sl = slots
            val fw = f.w.toFloat()
            val prev = stable.copyOf()
            for (i in 0 until n) {
                val s = sl[i]
                val cx = s.x * fw
                val cy = s.y * fw
                val rr = s.r * fw
                var r = Classifier.quick(f, cx, cy, rr, offs[i])
                if (Classifier.lastStrong) {
                    aligned[i] = true
                } else if (wantDeep(i, now, Classifier.lastMax)) {
                    lastDeep[i] = now
                    r = Classifier.classify(f, cx, cy, rr, offs[i])
                    if (Classifier.lastStrong) aligned[i] = true
                }
                raw[i] = r
            }
            val ch = BooleanArray(n)
            for (i in 0 until n) {
                val r = raw[i]
                if (r == Classifier.UNK) { cand[i] = -1; candN[i] = 0; continue }
                if (stable[i] == -1) { stable[i] = r; continue }
                if (r == stable[i]) { cand[i] = -1; candN[i] = 0; continue }
                if (r == cand[i]) candN[i]++ else { cand[i] = r; candN[i] = 1 }
                if (candN[i] >= confirm) { stable[i] = r; cand[i] = -1; candN[i] = 0; ch[i] = true }
            }
            if (mode == MAGNET) { magnetStep(f, now, ch); return }
            if (!armed) return
            if (now < cooldownUntil) return

            if (mode == OPEN) {
                // locked -> open : go down right there (mics that were already open are ignored)
                for (i in 0 until n) {
                    if (ch[i] && prev[i] == Classifier.LOCKED && stable[i] == Classifier.EMPTY && !sl[i].host && okSeat(i)) {
                        fire(i, now)
                        return
                    }
                }
            } else if (mode == WATCH) {
                // somebody leaves a mic -> take the seat they just left
                for (i in 0 until n) {
                    if (ch[i] && prev[i] == Classifier.OCC && stable[i] == Classifier.EMPTY && !sl[i].host && okSeat(i)) {
                        fire(i, now)
                        return
                    }
                }
            } else if (mode == FOLLOW) {
                // everyone empty, then someone steps up -> take another free mic right after
                var trig = -1
                for (i in 0 until n) {
                    if (ch[i] && prev[i] == Classifier.EMPTY && stable[i] == Classifier.OCC && !sl[i].host && okSeat(i)) { trig = i; break }
                }
                if (trig >= 0) {
                    var clean = true
                    for (k in 0 until n) {
                        if (!sl[k].host && prev[k] == Classifier.OCC) { clean = false; break }
                    }
                    if (clean) {
                        for (d in 1 until n) {
                            val t = (trig + d) % n
                            if (!sl[t].host && stable[t] == Classifier.EMPTY) { fire(t, now); return }
                        }
                    }
                }
            }
        }
    }

    /** The full alignment search is expensive: only run it when it can change the answer. */
    private fun wantDeep(i: Int, now: Long, m: Float): Boolean {
        val since = now - lastDeep[i]
        return if (aligned[i]) (m >= 0.45f && since >= 60L)
        else (since >= 250L || (m >= 0.55f && since >= 60L))
    }

    // ------------------------------------------------------------------ taps
    private fun fire(i: Int, now: Long) {
        cooldownUntil = now + cooldown
        tapSlot(i)
        say(R.string.p_grab, i + 1)
        if (retry) {
            main.postDelayed({
                val st = synchronized(lock) { if (i < stable.size) stable[i] else -1 }
                val popupSeen = autoConfirm && (popupAt > now || SystemClock.uptimeMillis() < popupUntil)
                if (armed && st == Classifier.EMPTY && !popupSeen) tapSlot(i)
            }, 450)
        }
    }

    /** Taps seat number i (0-based). Used by every mode and by the number pad. */
    fun tapSlot(i: Int, force: Boolean = false) {
        val s = slots.getOrNull(i) ?: return
        val svc = ClickService.instance ?: return
        val o = offs.getOrNull(i)
        val fw = frameW
        val k = if (fw > 0) screenW / fw else 1f
        val px = s.x * screenW + (o?.get(0) ?: 0) * k
        val py = s.y * screenW + (o?.get(1) ?: 0) * k
        if (autoConfirm || force) { popupUntil = SystemClock.uptimeMillis() + 2500L; confirmOnly = false }
        svc.tap(px, py, dbl)
    }

    // ------------------------------------------------------------------ auto layout + calibration
    // Everything below runs on the worker thread, on a private copy of the frame.
    private const val JOB_REFIT = 1
    private const val JOB_DETECT = 2
    private const val JOB_SCAN = 3
    private const val JOB_FIT = 4
    private const val JOB_VERIFY = 5

    private class RowRes(val hits: Int, val dy: Float, val sum: Float, val xs: Float = 1f, val dx: Float = 0f)

    private class CalSnap(
        val sl: List<Slot>, val done: BooleanArray, val k: Float,
        val dy: FloatArray, val xs: FloatArray, val dx: FloatArray, val nudge: Float
    )

    /** Strong icon matches (lock / mic) of one row, and their total score, at a given shift / spacing. */
    private fun scoreRowAt(f: Frame, sl: List<Slot>, idxs: List<Int>, k: Float, xs: Float, dx: Float, dyPx: Int, out: FloatArray) {
        val fw = f.w.toFloat()
        var hits = 0
        var sum = 0f
        for (i in idxs) {
            val s = sl[i]
            val x = if (s.host) s.x else 0.5f + (s.x - 0.5f) * xs + dx
            val m = Classifier.best(f, x * fw, s.y * fw + dyPx, s.r * fw * k)
            if (m >= 0.75f) { hits++; sum += m }
        }
        out[0] = hits.toFloat()
        out[1] = sum
    }

    /**
     * Slides a row up / down looking for lock / mic icons. With spacing = true it also stretches the row
     * around the screen centre and shifts it sideways, so a room whose mics are wider or tighter than the
     * preset is still matched seat by seat (same order, only the positions are corrected).
     */
    private fun searchRow(
        f: Frame, sl: List<Slot>, idxs: List<Int>, k: Float,
        centerPx: Int, rangePx: Int, step: Int, spacing: Boolean
    ): RowRes {
        val fw = f.w.toFloat()
        val maxP = (rangePx / step) * step
        val tmp = FloatArray(2)
        val nxs = if (spacing) 14 else 1
        val ndx = if (spacing) 11 else 1
        var bestAdj = -1f
        var bestHits = 0
        var bestSum = 0f
        var bestD = 0
        var bestXs = 1f
        var bestDx = 0f
        for (qx in 0 until nxs) {
            val xs = if (spacing) 0.88f + 0.02f * qx else 1f
            for (qd in 0 until ndx) {
                val dx = if (spacing) -0.03f + 0.006f * qd else 0f
                var d = centerPx - maxP
                while (d <= centerPx + maxP) {
                    scoreRowAt(f, sl, idxs, k, xs, dx, d, tmp)
                    val hits = tmp[0].toInt()
                    if (hits > 0) {
                        // small penalties: when two fits score the same, prefer the one closest to the preset
                        val adj = tmp[1] - 0.003f * Math.abs(d) - 0.5f * Math.abs(xs - 1f) - 1f * Math.abs(dx)
                        if (adj > bestAdj) {
                            bestAdj = adj; bestHits = hits; bestSum = tmp[1]
                            bestD = d; bestXs = xs; bestDx = dx
                        }
                    }
                    d += step
                }
            }
        }
        return RowRes(bestHits, bestD / fw, bestSum, bestXs, bestDx)
    }

    /** Vertical fit first (cheap); then, for rows with 2+ seats, the horizontal spacing / shift too. */
    private fun fitRow(f: Frame, sl: List<Slot>, idxs: List<Int>, k: Float): RowRes {
        val fw = f.w.toFloat()
        val v = searchRow(f, sl, idxs, k, 0, Math.round(0.12f * fw), 3, false)
        if (idxs.size < 2) return v
        if (v.hits >= 2) {
            val c = Math.round(v.dy * fw)
            val sp = searchRow(f, sl, idxs, k, c, Math.round(0.012f * fw), 3, true)
            return if (sp.sum >= v.sum) sp else v
        }
        // no icons at the preset spacing: the spacing is probably off, so look for both together
        val sp = searchRow(f, sl, idxs, k, 0, Math.round(0.12f * fw), 4, true)
        return if (sp.hits >= 2) sp else v
    }

    private fun detectGap(smart: Boolean): Long =
        if (smart) 6000L else if (detectFails < 3) 1500L else if (detectFails < 8) 4000L else 8000L

    private fun maintain(f: Frame, now: Long) {
        if (now - lastMaint < 300L) return
        lastMaint = now
        if (!auto && !calOn) return
        if (workBusy.get()) return
        val user = scanNow
        // never compete with a tap or a pop-up that is in flight
        if (!user && (now < popupUntil + 1500L || now - popupAt < 2500L || now < cooldownUntil)) return

        var hitsNow = 0
        var pending = false
        synchronized(lock) {
            for (v in stable) if (v == Classifier.LOCKED || v == Classifier.EMPTY) hitsNow++
            if (calOn) for (b in rowDone) if (!b) { pending = true; break }
        }
        if (hitsNow >= 3) detectFails = 0
        val smart = currentId == "smart"

        var job = 0
        if (user) job = JOB_REFIT
        else if (auto && hitsNow < 3 && now - lastDet >= detectGap(smart) && (!armed || hitsNow == 0) && (!smart || !armed)) job = JOB_DETECT
        else if (auto && detectFails >= 6 && now - lastScan >= 6000L && (!armed || hitsNow < 2)) job = JOB_SCAN
        else if (calOn && pending && (!armed || hitsNow < 2) && now - lastCal >= 1500L) job = JOB_FIT
        else if (calOn && !pending && !armed && hitsNow >= 2 && now - lastVerify >= 5000L) job = JOB_VERIFY
        if (job == 0) return

        val jf = jobFrame?.takeIf { it.w == f.w && it.h == f.h } ?: Frame(f.w, f.h).also { jobFrame = it }
        jf.copyFrom(f)
        if (user) scanNow = false
        when (job) {
            JOB_DETECT -> lastDet = now
            JOB_SCAN -> lastScan = now
            JOB_FIT -> lastCal = now
            JOB_VERIFY -> lastVerify = now
        }
        workBusy.set(true)
        worker.post {
            try { runJob(job, jf) } catch (_: Throwable) {} finally { workBusy.set(false) }
        }
    }

    private fun runJob(job: Int, f: Frame) {
        when (job) {
            JOB_REFIT -> {
                synchronized(lock) {
                    if (calOn) {
                        resetCal(rowDone.size)
                        rebuild()
                        for (i in offs.indices) { offs[i][0] = 0; offs[i][1] = 0; aligned[i] = false }
                        saveCal()
                    }
                }
                val ok = if (auto) detect(f, true, true) else true
                fit(f, false)
                if (auto && !ok) scan(f, true)
                main.post { ClickService.instance?.refreshUi() }
            }
            JOB_DETECT -> detect(f, detectFails >= 1, false)
            JOB_SCAN -> scan(f, false)
            JOB_FIT -> fit(f, false)
            JOB_VERIFY -> fit(f, true)
        }
    }

    private fun sameSeats(a: List<Slot>, b: List<Slot>): Boolean {
        if (a.size != b.size) return false
        for (i in a.indices) {
            if (Math.abs(a[i].x - b[i].x) > 0.03f || Math.abs(a[i].y - b[i].y) > 0.03f || Math.abs(a[i].r - b[i].r) > 0.02f) return false
        }
        return true
    }

    /** Last resort, only when no known preset matches the screen: count the seats from the circles. */
    private fun scan(f: Frame, force: Boolean) {
        val res = SeatFinder.find(f)
        if (res.size < 2) return
        if (currentId == "smart") {
            if (sameSeats(res, base)) return
            if (!force && res.size < base.size) return
        }
        if (!force) {
            // a random screen full of round things must not replace the layout: demand real lock / mic icons
            val fw = f.w.toFloat()
            var icons = 0
            for (s in res) if (Classifier.best(f, s.x * fw, s.y * fw, s.r * fw) >= 0.75f) icons++
            if (icons < 2) return
        }
        setLayout(Layout("smart", R.string.lay_auto, res))
        say(R.string.scan_found, res.size)
        main.post { ClickService.instance?.refreshUi() }
    }

    /**
     * Finds which preset matches the screen. deep = also tolerate different spacing (slower, used after
     * the quick pass failed). immediate = switch right away instead of waiting for two agreeing passes.
     * Returns true when some preset matched.
     */
    private fun detect(f: Frame, deep: Boolean, immediate: Boolean): Boolean {
        val fw = f.w.toFloat()
        var bestId: String? = null
        var bestHits = -1
        var bestPen = 0f
        var bestSize = 0
        var curHits = 0
        val rng = Math.round(0.10f * fw)
        for (l in Layouts.presets) {
            var hits = 0
            var pen = 0f
            val rows = Layouts.rowsOf(l.slots)
            for (row in rows) {
                val res = if (deep && row.size >= 2) searchRow(f, l.slots, row, 1f, 0, Math.round(0.08f * fw), 4, true)
                else searchRow(f, l.slots, row, 1f, 0, rng, 3, false)
                hits += res.hits
                if (res.hits > 0) pen += Math.abs(res.dy)
            }
            if (l.id == currentId) curHits = hits
            val better = hits > bestHits ||
                (hits == bestHits && (pen < bestPen - 0.01f || (Math.abs(pen - bestPen) <= 0.01f && l.slots.size < bestSize)))
            if (better) { bestHits = hits; bestPen = pen; bestSize = l.slots.size; bestId = l.id }
        }
        if (bestId == null || bestHits < 3) { detectFails++; pendId = null; pendN = 0; return false }
        detectFails = 0
        if (bestId == currentId || bestHits < curHits + 2) { pendId = null; pendN = 0; return true }
        if (bestId == pendId) pendN++ else { pendId = bestId; pendN = 1 }
        if (immediate || pendN >= 2) {
            pendId = null; pendN = 0
            Prefs.detected = bestId
            setLayout(Layouts.current())
            main.post { ClickService.instance?.refreshUi() }
        }
        return true
    }

    /**
     * Fits every row of the preset to what is really on screen (row height, seat size, spacing, shift).
     * verify = the rows are already fitted: only move one when the new fit is clearly better, which
     * is how a change in the room (wider spacing, moved rows) is corrected without any user action.
     */
    private fun fit(f: Frame, verify: Boolean) {
        val fw = f.w.toFloat()
        val snap = synchronized(lock) {
            if (!calOn) null
            else CalSnap(base, rowDone.copyOf(), calK, calDy.copyOf(), calXs.copyOf(), calDx.copyOf(), calNudge)
        } ?: return
        val sl = snap.sl
        val rows = Layouts.rowsOf(sl)
        if (rows.size != snap.done.size) return
        var pending = 0
        var anyDone = false
        for (b in snap.done) { if (b) anyDone = true else pending++ }
        if (!verify && pending == 0) return

        // seat size: measured once, while no row has been fitted yet
        var kUse = snap.k
        if (!anyDone && !verify) {
            val ks = floatArrayOf(1f, 0.88f, 1.12f, 1.28f)
            var bestTot = 0f
            for (k in ks) {
                var tot = 0f
                for (r in rows.indices) tot += searchRow(f, sl, rows[r], k, 0, Math.round(0.12f * fw), 3, false).sum
                if (tot > bestTot) { bestTot = tot; kUse = k }
            }
            if (bestTot <= 0f) return
        }

        val res = arrayOfNulls<RowRes>(rows.size)
        val cur = FloatArray(rows.size)
        val tmp = FloatArray(2)
        for (r in rows.indices) {
            if (snap.done[r] && !verify) continue
            res[r] = fitRow(f, sl, rows[r], kUse)
            if (snap.done[r]) {
                scoreRowAt(f, sl, rows[r], kUse, snap.xs[r], snap.dx[r], Math.round((snap.dy[r] + snap.nudge) * fw), tmp)
                cur[r] = tmp[1]
            }
        }

        var changed = false
        synchronized(lock) {
            if (base !== sl || rowDone.size != rows.size) return
            for (r in rows.indices) {
                val rr = res[r] ?: continue
                if (!rowDone[r]) {
                    if (rr.hits >= 2 || rr.sum >= 0.8f) {
                        calDy[r] = rr.dy; calXs[r] = rr.xs; calDx[r] = rr.dx
                        rowDone[r] = true
                        changed = true
                    }
                } else if (rr.hits >= 2 && rr.sum > cur[r] + 0.6f) {
                    calDy[r] = rr.dy; calXs[r] = rr.xs; calDx[r] = rr.dx
                    changed = true
                }
            }
            if (changed) {
                if (!anyDone && !verify) calK = kUse
                calNudge = 0f
                rebuild()
                for (i in offs.indices) { offs[i][0] = 0; offs[i][1] = 0; aligned[i] = false }
                saveCal()
            }
        }
        if (changed) main.post { ClickService.instance?.refreshUi() }
    }

    // ------------------------------------------------------------------ magnet
    private fun mgReset() {
        mgTarget = -1
        mgMe = -1
        mgPhase = 0
        mgSig = null
        mgSigPending = false
        mgLeftAt = 0L
        mgWantUp = false
        mgExitSeat = -1
        mgTakeSeat = -1
    }

    /** Choose (or un-choose) the person to follow. */
    fun mgPickTarget(i: Int) {
        synchronized(lock) {
            if (i < 0 || i >= slots.size) return
            if (mgTarget == i) {
                mgTarget = -1; mgSig = null; mgSigPending = false; mgWantUp = false
                return
            }
            mgTarget = i
            mgSig = null
            mgSigPending = true
            mgLeftAt = 0L
            mgWantUp = false
            mgPhase = if (stable.getOrElse(i) { -1 } == Classifier.OCC) 0 else 1
            if (mgMe == i) mgMe = -1
        }
    }

    /** Tell the app which seat I am sitting on right now. */
    fun mgPickMe(i: Int) {
        synchronized(lock) {
            if (i < 0 || i >= slots.size) return
            if (mgMe == i) { mgMe = -1; return }
            mgMe = i
            mgLastMe = i
            if (mgTarget == i) { mgTarget = -1; mgSig = null; mgSigPending = false }
        }
    }

    private fun sigScore(f: Frame, i: Int): Float {
        val ref = mgSig ?: return 0f
        val s = slots[i]
        val fw = f.w.toFloat()
        return Sig.match(f, s.x * fw + offs[i][0], s.y * fw + offs[i][1], s.r * fw, ref)
    }

    private fun sigNow(f: Frame, i: Int): IntArray {
        val s = slots[i]
        val fw = f.w.toFloat()
        return Sig.of(f, s.x * fw + offs[i][0], s.y * fw + offs[i][1], s.r * fw)
    }

    /** Looks for the target's face on any freshly occupied seat. Returns the seat or -1. */
    private fun findTarget(f: Frame, now: Long, exclude: Int): Int {
        val n = slots.size
        if (mgSig == null) {
            val t = mgTarget
            if (mgPhase == 1 && t in 0 until n && stable[t] == Classifier.OCC) {
                mgSig = sigNow(f, t)
                return t
            }
            return -1
        }
        var best = -1
        var bs = 0.72f
        for (i in 0 until n) {
            if (i == exclude || i == mgMe) continue
            if (stable[i] != Classifier.OCC) continue
            if (now > watchUntil[i]) continue
            if (now - lastSig[i] < 45L) continue
            lastSig[i] = now
            val sc = sigScore(f, i)
            if (sc > bs) { bs = sc; best = i }
        }
        return best
    }

    private fun pickFree(near: Int): Int {
        val n = slots.size
        if (focus in 0 until n) return if (stable[focus] == Classifier.EMPTY && !slots[focus].host) focus else -1
        if (mgLastMe in 0 until n && stable[mgLastMe] == Classifier.EMPTY && !slots[mgLastMe].host) return mgLastMe
        var best = -1
        var bd = 999
        for (i in 0 until n) {
            if (slots[i].host || stable[i] != Classifier.EMPTY || i == near) continue
            val d = Math.abs(i - near)
            if (d < bd) { bd = d; best = i }
        }
        return best
    }

    private fun magnetStep(f: Frame, now: Long, ch: BooleanArray) {
        val n = slots.size
        for (i in 0 until n) {
            if (ch[i] && stable[i] == Classifier.OCC) watchUntil[i] = now + 900L
        }
        val t = mgTarget
        if (t < 0 || t >= n) return
        if (mgSigPending && stable[t] == Classifier.OCC) {
            mgSig = sigNow(f, t)
            mgSigPending = false
        }
        takeVerify(now)
        if (!armed) return

        if (mgPhase == 0) {
            val st = stable[t]
            if (st == Classifier.EMPTY || st == Classifier.LOCKED) {
                if (mgLeftAt == 0L) mgLeftAt = now
                val k = findTarget(f, now, t)
                if (k >= 0) {
                    mgTarget = k          // he only changed seat
                    mgLeftAt = 0L
                } else if (now - mgLeftAt >= (if (mgSig != null) 140L else 0L)) {
                    mgLeftAt = 0L
                    mgPhase = 1
                    mgWantUp = false
                    exitNow(now)
                }
            } else {
                mgLeftAt = 0L
            }
        } else {
            val k = findTarget(f, now, -1)
            if (k >= 0) {
                mgTarget = k
                mgPhase = 0
                mgWantUp = true
                mgWantAt = now
            }
        }
        if (mgWantUp) upStep(now)
        exitVerify(now)
    }

    /** He left: tap my own seat, the pop-up handler then presses "Exit mic". */
    private fun exitNow(now: Long) {
        val me = mgMe
        if (me < 0 || me >= slots.size || stable[me] != Classifier.OCC) {
            say(R.string.mg_nome)
            return
        }
        mgLastMe = me
        mgExitSeat = me
        mgExitTries = 2
        mgExitAt = now + 900L
        tapSlot(me, true)
        say(R.string.mg_exit)
    }

    private fun exitVerify(now: Long) {
        val s = mgExitSeat
        if (s < 0) return
        if (stable[s] != Classifier.OCC) { mgMe = -1; mgExitSeat = -1; return }
        if (now >= mgExitAt) {
            if (mgPhase == 1 && mgExitTries > 0) {
                mgExitTries--
                mgExitAt = now + 900L
                tapSlot(s, true)
            } else {
                mgExitSeat = -1
            }
        }
    }

    /** He is back: go up again (my old seat if it is free, otherwise the nearest free one). */
    private fun upStep(now: Long) {
        if (now < mgBusyUntil) return
        if (mgMe >= 0 && mgMe < slots.size && stable[mgMe] == Classifier.OCC) { mgWantUp = false; return }
        if (now - mgWantAt > 8000L) { mgWantUp = false; return }
        val s = pickFree(mgTarget)
        if (s < 0) return
        mgWantUp = false
        mgBusyUntil = now + 600L
        mgTakeSeat = s
        mgTakeAt = now + 1100L
        mgTakeTries = 2
        tapSlot(s, true)
        say(R.string.mg_up, s + 1)
    }

    private fun takeVerify(now: Long) {
        val s = mgTakeSeat
        if (s < 0) return
        if (stable[s] == Classifier.OCC) { mgMe = s; mgLastMe = s; mgTakeSeat = -1; return }
        if (now >= mgTakeAt) {
            if (mgTakeTries > 0 && mgPhase == 0) {
                mgTakeTries--
                val s2 = if (stable[s] == Classifier.EMPTY) s else pickFree(mgTarget)
                if (s2 >= 0) { tapSlot(s2, true); mgTakeSeat = s2; mgTakeAt = now + 1100L } else mgTakeSeat = -1
            } else {
                mgTakeSeat = -1
            }
        }
    }
}
