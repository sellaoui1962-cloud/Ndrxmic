package com.ndrx.mic

import android.os.Handler
import android.os.Looper
import android.os.SystemClock

object Engine {
    const val OPEN = 0
    const val FOLLOW = 1
    const val PAD = 2
    const val WATCH = 3

    @Volatile var mode = OPEN
    @Volatile var armed = false
    @Volatile var capturing = false
    @Volatile var screenW = 1080f
    @Volatile var frameW = 0

    var slots: List<Slot> = emptyList()
        private set
    var onStatus: ((String) -> Unit)? = null

    private val lock = Any()
    private val main = Handler(Looper.getMainLooper())
    private var raw = IntArray(0)
    private var stable = IntArray(0)
    private var cand = IntArray(0)
    private var candN = IntArray(0)
    private var offs: Array<IntArray> = emptyArray()
    private var cooldownUntil = 0L
    private var confirm = 1
    private var cooldown = 3000
    private var retry = true
    private var dbl = false
    private var auto = false
    private var lastDet = 0L
    private var pendId: String? = null
    private var pendN = 0
    @Volatile var currentId = ""
    @Volatile private var popupUntil = 0L
    @Volatile private var popupAt = 0L
    private var autoConfirm = true

    fun load() {
        mode = Prefs.mode
        confirm = Prefs.confirm
        cooldown = Prefs.cooldown
        retry = Prefs.retry
        dbl = Prefs.doubleTap
        autoConfirm = Prefs.autoConfirm
        auto = Prefs.layoutId == "auto"
        pendId = null; pendN = 0
        val m = App.ctx.resources.displayMetrics
        screenW = Math.min(m.widthPixels, m.heightPixels).toFloat()
        setLayout(Layouts.current())
    }

    private fun setLayout(l: Layout) {
        synchronized(lock) {
            currentId = l.id
            slots = l.slots
            val n = slots.size
            raw = IntArray(n) { Classifier.UNK }
            stable = IntArray(n) { -1 }
            cand = IntArray(n) { -1 }
            candN = IntArray(n)
            offs = Array(n) { IntArray(2) }
        }
    }

    fun snapshot(): IntArray = synchronized(lock) { raw.copyOf() }

    private fun status(s: String) { onStatus?.invoke(s) }

    /** Looks at the screen and picks the preset whose seats match the most lock / mic icons. */
    private fun detect(f: Frame) {
        val fw = f.w.toFloat()
        var bestId: String? = null
        var bestHits = 0
        var bestSize = 0
        for (l in Layouts.presets) {
            var hits = 0
            for (s in l.slots) {
                val r = Classifier.classify(f, s.x * fw, s.y * fw, s.r * fw, IntArray(2))
                if (r == Classifier.LOCKED || r == Classifier.EMPTY) hits++
            }
            if (hits > bestHits || (hits == bestHits && hits > 0 && l.slots.size < bestSize)) {
                bestHits = hits; bestId = l.id; bestSize = l.slots.size
            }
        }
        if (bestId == null || bestHits < 2) { pendId = null; pendN = 0; return }
        if (bestId == currentId) { pendId = null; pendN = 0; return }
        if (bestId == pendId) pendN++ else { pendId = bestId; pendN = 1 }
        if (pendN >= 2) {
            pendId = null; pendN = 0
            Prefs.detected = bestId
            setLayout(Layouts.current())
            main.post { ClickService.instance?.refreshUi() }
        }
    }

    fun onFrame(f: Frame) {
        if (auto) {
            val t = SystemClock.uptimeMillis()
            if (t - lastDet > 700) { lastDet = t; detect(f) }
        }
        if (autoConfirm) {
            val t = SystemClock.uptimeMillis()
            if (t < popupUntil) {
                val h = Popup.find(f)
                if (h != null) {
                    popupUntil = 0L
                    popupAt = t
                    val k = screenW / f.w
                    ClickService.instance?.tap(h.x * k, h.y * k, false)
                }
            }
        }
        if (mode == PAD) return
        synchronized(lock) {
            frameW = f.w
            val n = slots.size
            if (n == 0) return
            val fw = f.w.toFloat()
            val prev = stable.copyOf()
            for (i in 0 until n) {
                val s = slots[i]
                raw[i] = Classifier.classify(f, s.x * fw, s.y * fw, s.r * fw, offs[i])
            }
            val ch = BooleanArray(n)
            for (i in 0 until n) {
                val r = raw[i]
                if (r == Classifier.UNK) { cand[i] = -1; candN[i] = 0; continue }
                if (stable[i] == -1) { stable[i] = r; continue }
                if (r == stable[i]) { cand[i] = -1; candN[i] = 0; continue }
                if (r == cand[i]) candN[i]++ else { cand[i] = r; candN[i] = 1 }
                if (candN[i] >= confirm) { stable[i] = r; cand[i] = -1; candN[i] = 0; ch[i] = true }
            }
            if (!armed) return
            val now = SystemClock.uptimeMillis()
            if (now < cooldownUntil) return

            if (mode == OPEN) {
                // locked -> open : go down right there (mics that were already open are ignored)
                for (i in 0 until n) {
                    if (ch[i] && prev[i] == Classifier.LOCKED && stable[i] == Classifier.EMPTY && !slots[i].host) {
                        fire(i, now)
                        return
                    }
                }
            } else if (mode == WATCH) {
                // somebody leaves a mic -> take the seat they just left
                for (i in 0 until n) {
                    if (ch[i] && prev[i] == Classifier.OCC && stable[i] == Classifier.EMPTY && !slots[i].host) {
                        fire(i, now)
                        return
                    }
                }
            } else if (mode == FOLLOW) {
                // everyone empty, then someone steps up -> take another free mic right after
                var trig = -1
                for (i in 0 until n) {
                    if (ch[i] && prev[i] == Classifier.EMPTY && stable[i] == Classifier.OCC && !slots[i].host) { trig = i; break }
                }
                if (trig >= 0) {
                    var clean = true
                    for (k in 0 until n) {
                        if (!slots[k].host && prev[k] == Classifier.OCC) { clean = false; break }
                    }
                    if (clean) {
                        for (d in 1 until n) {
                            val t = (trig + d) % n
                            if (!slots[t].host && stable[t] == Classifier.EMPTY) { fire(t, now); return }
                        }
                    }
                }
            }
        }
    }

    private fun fire(i: Int, now: Long) {
        cooldownUntil = now + cooldown
        tapSlot(i)
        status(Loc.wrap(App.ctx).getString(R.string.p_grab, i + 1))
        if (retry) {
            main.postDelayed({
                val st = synchronized(lock) { if (i < stable.size) stable[i] else -1 }
                val popupSeen = autoConfirm && (popupAt > now || SystemClock.uptimeMillis() < popupUntil)
                if (armed && st == Classifier.EMPTY && !popupSeen) tapSlot(i)
            }, 450)
        }
    }

    /** Taps the seat number i (0-based). Used by every mode and by the number pad. */
    fun tapSlot(i: Int) {
        val s = slots.getOrNull(i) ?: return
        val svc = ClickService.instance ?: return
        val o = offs.getOrNull(i)
        val fw = frameW
        val k = if (fw > 0) screenW / fw else 1f
        val px = s.x * screenW + (o?.get(0) ?: 0) * k
        val py = s.y * screenW + (o?.get(1) ?: 0) * k
        if (autoConfirm) popupUntil = SystemClock.uptimeMillis() + 2500
        svc.tap(px, py, dbl)
    }
}
