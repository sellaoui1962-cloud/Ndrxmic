package com.ndrx.mic

import android.os.Handler
import android.os.Looper
import android.os.SystemClock

/**
 * Reads the mic seats from every captured frame and decides when to tap.
 * Modes: OPEN (catch a mic the instant it opens), FOLLOW, PAD (manual numbers),
 * WATCH (take over a seat the moment its owner leaves) and MAGNET (shadow one person:
 * leave the mic when he leaves, go back up when he comes back).
 */
object Engine {
    const val OPEN = 0
    const val FOLLOW = 1
    const val PAD = 2
    const val WATCH = 3
    const val MAGNET = 4

    @Volatile var mode = OPEN
    @Volatile var armed = false
    @Volatile var capturing = false
    @Volatile var screenW = 1080f
    @Volatile var frameW = 0
    @Volatile var currentId = ""

    @Volatile var slots: List<Slot> = emptyList()
        private set
    var onStatus: ((String) -> Unit)? = null

    // ---- magnet state shown by the UI
    // ---- focus ("Rasd"): act on one seat only, with any mode
    @Volatile var focus = -1
        private set
    @Volatile var focusPick = false

    @Volatile var mgTarget = -1
        private set
    @Volatile var mgMe = -1
        private set
    @Volatile var mgPhase = 0          // 0 = target is on a mic, 1 = target is away
        private set

    private val lock = Any()
    private val main = Handler(Looper.getMainLooper())

    // ---- layout + calibration
    private var base: List<Slot> = emptyList()
    private var rowIdx = IntArray(0)
    private var calDy = FloatArray(0)
    private var rowDone = BooleanArray(0)
    private var calK = 1f
    private var calNudge = 0f
    private var calOn = true

    // ---- per-seat reading state
    private var raw = IntArray(0)
    private var stable = IntArray(0)
    private var cand = IntArray(0)
    private var candN = IntArray(0)
    private var offs: Array<IntArray> = emptyArray()
    private var aligned = BooleanArray(0)
    private var lastDeep = LongArray(0)
    private var watchUntil = LongArray(0)
    private var lastSig = LongArray(0)

    // ---- settings
    private var cooldownUntil = 0L
    private var confirm = 1
    private var cooldown = 3000
    private var retry = true
    private var dbl = false
    private var auto = false
    private var autoConfirm = true
    private var lastMaint = 0L
    private var lastDet = 0L
    private var lastCal = 0L
    private var pendId: String? = null
    private var pendN = 0

    // ---- smart scan (counts the seats on screen)
    private var smartList: List<Slot>? = null
    private var lastScan = 0L
    private var scanFails = 0
    @Volatile private var scanNow = false

    // ---- pop-ups after a seat tap
    @Volatile private var popupUntil = 0L
    @Volatile private var popupAt = 0L
    @Volatile private var confirmOnly = false

    // ---- magnet internals
    private var mgSig: IntArray? = null
    private var mgSigPending = false
    private var mgLeftAt = 0L
    private var mgLastMe = -1
    private var mgWantUp = false
    private var mgWantAt = 0L
    private var mgBusyUntil = 0L
    private var mgExitSeat = -1
    private var mgExitAt = 0L
    private var mgExitTries = 0
    private var mgTakeSeat = -1
    private var mgTakeAt = 0L
    private var mgTakeTries = 0

    // ------------------------------------------------------------------ setup
    fun load() {
        mode = Prefs.mode
        Classifier.turbo = Prefs.turbo
        Classifier.deep = Prefs.deep
        Popup.relaxed = Prefs.turbo
        confirm = if (Prefs.turbo) 1 else Prefs.confirm
        cooldown = Prefs.cooldown
        retry = Prefs.retry
        dbl = Prefs.doubleTap
        autoConfirm = Prefs.autoConfirm
        auto = Prefs.layoutId == "auto"
        pendId = null; pendN = 0
        val m = App.ctx.resources.displayMetrics
        screenW = Math.min(m.widthPixels, m.heightPixels).toFloat()
        val l = (if (auto) smartLayout() else null) ?: Layouts.current()
        if (l.id == currentId && l.slots == base && base.isNotEmpty()) return
        setLayout(l)
    }

    private fun smartLayout(): Layout? {
        var s = smartList
        if (s == null) {
            s = smartParse(Prefs.calGet("smartlist"))
            if (s.size >= 2) smartList = s
        }
        if (s.size < 2) return null
        return Layout("smart", R.string.lay_auto, s)
    }

    private fun smartParse(t: String): List<Slot> {
        val out = ArrayList<Slot>()
        if (t.isBlank()) return out
        for (q in t.split(";")) {
            val p = q.split(",")
            if (p.size >= 4) {
                try { out.add(Slot(p[0].toFloat(), p[1].toFloat(), p[2].toFloat(), p[3] == "1")) } catch (_: Exception) {}
            }
        }
        return out
    }

    private fun smartSerialize(l: List<Slot>): String =
        l.joinToString(";") { "${it.x},${it.y},${it.r},${if (it.host) 1 else 0}" }

    /** Forces a fresh count of the seats on the next frame. */
    fun requestScan() { scanNow = true }

    fun setFocus(i: Int) {
        if (i >= 0 && i < slots.size) focus = i
        focusPick = false
    }

    fun clearFocus() { focus = -1; focusPick = false }

    private fun okSeat(i: Int): Boolean = focus < 0 || i == focus

    private fun setLayout(l: Layout) {
        synchronized(lock) {
            currentId = l.id
            focus = -1
            focusPick = false
            base = l.slots
            calOn = l.id != "custom"
            val rows = Layouts.rowsOf(base)
            rowIdx = IntArray(base.size)
            for (r in rows.indices) {
                for (i in rows[r]) rowIdx[i] = r
            }
            loadCal(l.id, rows.size)
            rebuild()
            val n = base.size
            raw = IntArray(n) { Classifier.UNK }
            stable = IntArray(n) { -1 }
            cand = IntArray(n) { -1 }
            candN = IntArray(n)
            offs = Array(n) { IntArray(2) }
            aligned = BooleanArray(n)
            lastDeep = LongArray(n)
            watchUntil = LongArray(n)
            lastSig = LongArray(n)
            mgReset()
        }
    }

    private fun loadCal(id: String, rows: Int) {
        calK = 1f
        calNudge = 0f
        calDy = FloatArray(rows)
        rowDone = BooleanArray(rows)
        if (id == "smart") return
        val s = Prefs.calGet(id)
        if (s.isBlank()) return
        try {
            val p = s.split(";")
            val k = p[0].toFloat()
            val dys = p[1].split(",")
            val mask = p[2]
            val nu = p[3].toFloat()
            for (r in 0 until rows) {
                if (r < dys.size && dys[r].isNotEmpty()) calDy[r] = dys[r].toFloat()
                rowDone[r] = r < mask.length && mask[r] == '1'
            }
            calK = k
            calNudge = nu
        } catch (_: Exception) {
            calK = 1f
            calNudge = 0f
            calDy = FloatArray(rows)
            rowDone = BooleanArray(rows)
        }
    }

    private fun saveCal() {
        if (!calOn || currentId == "smart") return
        val sb = StringBuilder()
        sb.append(calK).append(';')
        sb.append(calDy.joinToString(",")).append(';')
        for (b in rowDone) sb.append(if (b) '1' else '0')
        sb.append(';').append(calNudge)
        Prefs.calSet(currentId, sb.toString())
    }

    /** Applies calibration (row shift, seat scale, manual nudge) on top of the preset geometry. */
    private fun rebuild() {
        val n = base.size
        val out = ArrayList<Slot>(n)
        for (i in 0 until n) {
            val s = base[i]
            if (!calOn) { out.add(s); continue }
            val r = rowIdx[i]
            val dy = (if (r < calDy.size) calDy[r] else 0f) + calNudge
            out.add(Slot(s.x, s.y + dy, s.r * calK, s.host))
        }
        slots = out
    }

    /** Manual fine-tune of every dot, in W units (positive = down). */
    fun nudge(dyW: Float) {
        synchronized(lock) {
            if (!calOn) return
            calNudge += dyW
            rebuild()
            saveCal()
        }
    }

    fun snapshot(): IntArray = synchronized(lock) { raw.copyOf() }

    private fun status(s: String) { onStatus?.invoke(s) }

    private fun say(id: Int, vararg a: Any) {
        try { status(Loc.wrap(App.ctx).getString(id, *a)) } catch (_: Exception) {}
    }

    // ------------------------------------------------------------------ per-frame entry
    fun onFrame(f: Frame) {
        try { run(f) } catch (_: Throwable) {}
    }

    private fun run(f: Frame) {
        val now = SystemClock.uptimeMillis()
        frameW = f.w

        // 1. pop-ups that follow a seat tap (Take mic / Exit mic / Confirm)
        if (now < popupUntil) {
            val h = if (confirmOnly) Popup.findConfirm(f) else Popup.find(f)
            if (h != null) {
                if (h.menu) { popupUntil = now + 1500L; confirmOnly = true } else { popupUntil = 0L; confirmOnly = false }
                popupAt = now
                val k = screenW / f.w
                ClickService.instance?.tap(h.x * k, h.y * k, false)
            }
        }

        // 2. layout auto-detect + row calibration (cheap, throttled)
        maintain(f, now)
        if (mode == PAD) return

        // 3. read the seats and react
        synchronized(lock) {
            val n = slots.size
            if (n == 0) return
            val sl = slots
            val fw = f.w.toFloat()
            val prev = stable.copyOf()
            for (i in 0 until n) {
                val s = sl[i]
                val cx = s.x * fw
                val cy = s.y * fw
                val rr = s.r * fw
                var r = Classifier.quick(f, cx, cy, rr, offs[i])
                if (Classifier.lastStrong) {
                    aligned[i] = true
                } else if (wantDeep(i, now, Classifier.lastMax)) {
                    lastDeep[i] = now
                    r = Classifier.classify(f, cx, cy, rr, offs[i])
                    if (Classifier.lastStrong) aligned[i] = true
                }
                raw[i] = r
            }
            val ch = BooleanArray(n)
            for (i in 0 until n) {
                val r = raw[i]
                if (r == Classifier.UNK) { cand[i] = -1; candN[i] = 0; continue }
                if (stable[i] == -1) { stable[i] = r; continue }
                if (r == stable[i]) { cand[i] = -1; candN[i] = 0; continue }
                if (r == cand[i]) candN[i]++ else { cand[i] = r; candN[i] = 1 }
                if (candN[i] >= confirm) { stable[i] = r; cand[i] = -1; candN[i] = 0; ch[i] = true }
            }
            if (mode == MAGNET) { magnetStep(f, now, ch); return }
            if (!armed) return
            if (now < cooldownUntil) return

            if (mode == OPEN) {
                // locked -> open : go down right there (mics that were already open are ignored)
                for (i in 0 until n) {
                    if (ch[i] && prev[i] == Classifier.LOCKED && stable[i] == Classifier.EMPTY && !sl[i].host && okSeat(i)) {
                        fire(i, now)
                        return
                    }
                }
            } else if (mode == WATCH) {
                // somebody leaves a mic -> take the seat they just left
                for (i in 0 until n) {
                    if (ch[i] && prev[i] == Classifier.OCC && stable[i] == Classifier.EMPTY && !sl[i].host && okSeat(i)) {
                        fire(i, now)
                        return
                    }
                }
            } else if (mode == FOLLOW) {
                // everyone empty, then someone steps up -> take another free mic right after
                var trig = -1
                for (i in 0 until n) {
                    if (ch[i] && prev[i] == Classifier.EMPTY && stable[i] == Classifier.OCC && !sl[i].host && okSeat(i)) { trig = i; break }
                }
                if (trig >= 0) {
                    var clean = true
                    for (k in 0 until n) {
                        if (!sl[k].host && prev[k] == Classifier.OCC) { clean = false; break }
                    }
                    if (clean) {
                        for (d in 1 until n) {
                            val t = (trig + d) % n
                            if (!sl[t].host && stable[t] == Classifier.EMPTY) { fire(t, now); return }
                        }
                    }
                }
            }
        }
    }

    /** The full alignment search is expensive: only run it when it can change the answer. */
    private fun wantDeep(i: Int, now: Long, m: Float): Boolean {
        val since = now - lastDeep[i]
        return if (aligned[i]) (m >= 0.45f && since >= 60L)
        else (since >= 250L || (m >= 0.55f && since >= 60L))
    }

    // ------------------------------------------------------------------ taps
    private fun fire(i: Int, now: Long) {
        cooldownUntil = now + cooldown
        tapSlot(i)
        say(R.string.p_grab, i + 1)
        if (retry) {
            main.postDelayed({
                val st = synchronized(lock) { if (i < stable.size) stable[i] else -1 }
                val popupSeen = autoConfirm && (popupAt > now || SystemClock.uptimeMillis() < popupUntil)
                if (armed && st == Classifier.EMPTY && !popupSeen) tapSlot(i)
            }, 450)
        }
    }

    /** Taps seat number i (0-based). Used by every mode and by the number pad. */
    fun tapSlot(i: Int, force: Boolean = false) {
        val s = slots.getOrNull(i) ?: return
        val svc = ClickService.instance ?: return
        val o = offs.getOrNull(i)
        val fw = frameW
        val k = if (fw > 0) screenW / fw else 1f
        val px = s.x * screenW + (o?.get(0) ?: 0) * k
        val py = s.y * screenW + (o?.get(1) ?: 0) * k
        if (autoConfirm || force) { popupUntil = SystemClock.uptimeMillis() + 2500L; confirmOnly = false }
        svc.tap(px, py, dbl)
    }

    // ------------------------------------------------------------------ auto layout + calibration
    private class RowRes(val hits: Int, val dy: Float, val sum: Float)

    /** Slides a row up/down (and scales its seats) looking for lock / mic icons. */
    private fun evalRow(f: Frame, sl: List<Slot>, idxs: List<Int>, k: Float, rangeW: Float): RowRes {
        val fw = f.w.toFloat()
        val maxP = Math.round(rangeW * fw)
        var bestAdj = -1f
        var bestHits = 0
        var bestSum = 0f
        var bestD = 0
        var d = -maxP
        while (d <= maxP) {
            var hits = 0
            var sum = 0f
            for (i in idxs) {
                val s = sl[i]
                val m = Classifier.best(f, s.x * fw, s.y * fw + d, s.r * fw * k)
                if (m >= 0.75f) { hits++; sum += m }
            }
            if (hits > 0) {
                val adj = sum - 0.003f * Math.abs(d)
                if (adj > bestAdj) { bestAdj = adj; bestHits = hits; bestSum = sum; bestD = d }
            }
            d += 3
        }
        return RowRes(bestHits, bestD / fw, bestSum)
    }

    private fun maintain(f: Frame, now: Long) {
        if (now - lastMaint < 300L) return
        lastMaint = now
        if (!auto && !calOn) return
        var hitsNow = 0
        synchronized(lock) {
            for (v in stable) if (v == Classifier.LOCKED || v == Classifier.EMPTY) hitsNow++
        }
        if (auto) {
            val quiet = now > popupUntil + 1500L && now - popupAt > 2500L
            val smart = currentId == "smart"
            val due = scanNow || (!smart && now - lastScan >= 1200L) || (smart && !armed && now - lastScan >= 8000L)
            if (due && quiet) {
                val force = scanNow
                scanNow = false
                lastScan = now
                scan(f, force)
            }
            if (!smart && scanFails >= 3 && hitsNow < 3 && now - lastDet >= 1500L) {
                lastDet = now
                detect(f)
            }
        }
        if (calOn && (!armed || hitsNow < 2) && now - lastCal >= 1500L) {
            lastCal = now
            calibrate(f)
        }
    }

    private fun sameSeats(a: List<Slot>, b: List<Slot>): Boolean {
        if (a.size != b.size) return false
        for (i in a.indices) {
            if (Math.abs(a[i].x - b[i].x) > 0.03f || Math.abs(a[i].y - b[i].y) > 0.03f || Math.abs(a[i].r - b[i].r) > 0.02f) return false
        }
        return true
    }

    private fun scan(f: Frame, force: Boolean) {
        val res = SeatFinder.find(f)
        if (res.size < 2) { scanFails++; return }
        scanFails = 0
        if (currentId == "smart") {
            if (sameSeats(res, base)) return
            if (!force && res.size < base.size) return
        }
        smartList = res
        Prefs.calSet("smartlist", smartSerialize(res))
        setLayout(Layout("smart", R.string.lay_auto, res))
        say(R.string.scan_found, res.size)
        main.post { ClickService.instance?.refreshUi() }
    }

    private fun detect(f: Frame) {
        var bestId: String? = null
        var bestHits = -1
        var bestPen = 0f
        var bestSize = 0
        var curHits = 0
        for (l in Layouts.presets) {
            var hits = 0
            var pen = 0f
            val rows = Layouts.rowsOf(l.slots)
            for (row in rows) {
                val res = evalRow(f, l.slots, row, 1f, 0.10f)
                hits += res.hits
                if (res.hits > 0) pen += Math.abs(res.dy)
            }
            if (l.id == currentId) curHits = hits
            val better = hits > bestHits ||
                (hits == bestHits && (pen < bestPen - 0.01f || (Math.abs(pen - bestPen) <= 0.01f && l.slots.size < bestSize)))
            if (better) { bestHits = hits; bestPen = pen; bestSize = l.slots.size; bestId = l.id }
        }
        if (bestId == null || bestHits < 3) { pendId = null; pendN = 0; return }
        if (bestId == currentId || bestHits < curHits + 2) { pendId = null; pendN = 0; return }
        if (bestId == pendId) pendN++ else { pendId = bestId; pendN = 1 }
        if (pendN >= 2) {
            pendId = null; pendN = 0
            Prefs.detected = bestId
            setLayout(Layouts.current())
            main.post { ClickService.instance?.refreshUi() }
        }
    }

    private fun calibrate(f: Frame) {
        val sl = base
        if (sl.isEmpty()) return
        val rows = Layouts.rowsOf(sl)
        if (rows.size != rowDone.size) return
        var pending = 0
        var anyDone = false
        for (b in rowDone) { if (b) anyDone = true else pending++ }
        if (pending == 0) return

        val ks = if (anyDone) floatArrayOf(calK) else floatArrayOf(1f, 0.88f, 1.12f, 1.28f)
        var bestK = calK
        var bestTot = 0f
        var bestRes: Array<RowRes?> = arrayOfNulls(rows.size)
        for (k in ks) {
            var tot = 0f
            val res: Array<RowRes?> = arrayOfNulls(rows.size)
            for (r in rows.indices) {
                if (rowDone[r]) continue
                val rr = evalRow(f, sl, rows[r], k, 0.12f)
                res[r] = rr
                tot += rr.sum
            }
            if (tot > bestTot) { bestTot = tot; bestK = k; bestRes = res }
        }
        if (bestTot <= 0f) return

        var changed = false
        synchronized(lock) {
            for (r in rows.indices) {
                val rr = bestRes[r] ?: continue
                if (rowDone[r]) continue
                if (rr.hits >= 2 || rr.sum >= 0.8f) {
                    calDy[r] = rr.dy
                    rowDone[r] = true
                    changed = true
                }
            }
            if (changed) {
                if (!anyDone) calK = bestK
                calNudge = 0f
                rebuild()
                for (i in offs.indices) { offs[i][0] = 0; offs[i][1] = 0; aligned[i] = false }
                saveCal()
            }
        }
        if (changed) main.post { ClickService.instance?.refreshUi() }
    }

    // ------------------------------------------------------------------ magnet
    private fun mgReset() {
        mgTarget = -1
        mgMe = -1
        mgPhase = 0
        mgSig = null
        mgSigPending = false
        mgLeftAt = 0L
        mgWantUp = false
        mgExitSeat = -1
        mgTakeSeat = -1
    }

    /** Choose (or un-choose) the person to follow. */
    fun mgPickTarget(i: Int) {
        synchronized(lock) {
            if (i < 0 || i >= slots.size) return
            if (mgTarget == i) {
                mgTarget = -1; mgSig = null; mgSigPending = false; mgWantUp = false
                return
            }
            mgTarget = i
            mgSig = null
            mgSigPending = true
            mgLeftAt = 0L
            mgWantUp = false
            mgPhase = if (stable.getOrElse(i) { -1 } == Classifier.OCC) 0 else 1
            if (mgMe == i) mgMe = -1
        }
    }

    /** Tell the app which seat I am sitting on right now. */
    fun mgPickMe(i: Int) {
        synchronized(lock) {
            if (i < 0 || i >= slots.size) return
            if (mgMe == i) { mgMe = -1; return }
            mgMe = i
            mgLastMe = i
            if (mgTarget == i) { mgTarget = -1; mgSig = null; mgSigPending = false }
        }
    }

    private fun sigScore(f: Frame, i: Int): Float {
        val ref = mgSig ?: return 0f
        val s = slots[i]
        val fw = f.w.toFloat()
        return Sig.match(f, s.x * fw + offs[i][0], s.y * fw + offs[i][1], s.r * fw, ref)
    }

    private fun sigNow(f: Frame, i: Int): IntArray {
        val s = slots[i]
        val fw = f.w.toFloat()
        return Sig.of(f, s.x * fw + offs[i][0], s.y * fw + offs[i][1], s.r * fw)
    }

    /** Looks for the target's face on any freshly occupied seat. Returns the seat or -1. */
    private fun findTarget(f: Frame, now: Long, exclude: Int): Int {
        val n = slots.size
        if (mgSig == null) {
            val t = mgTarget
            if (mgPhase == 1 && t in 0 until n && stable[t] == Classifier.OCC) {
                mgSig = sigNow(f, t)
                return t
            }
            return -1
        }
        var best = -1
        var bs = 0.72f
        for (i in 0 until n) {
            if (i == exclude || i == mgMe) continue
            if (stable[i] != Classifier.OCC) continue
            if (now > watchUntil[i]) continue
            if (now - lastSig[i] < 45L) continue
            lastSig[i] = now
            val sc = sigScore(f, i)
            if (sc > bs) { bs = sc; best = i }
        }
        return best
    }

    private fun pickFree(near: Int): Int {
        val n = slots.size
        if (focus in 0 until n) return if (stable[focus] == Classifier.EMPTY && !slots[focus].host) focus else -1
        if (mgLastMe in 0 until n && stable[mgLastMe] == Classifier.EMPTY && !slots[mgLastMe].host) return mgLastMe
        var best = -1
        var bd = 999
        for (i in 0 until n) {
            if (slots[i].host || stable[i] != Classifier.EMPTY || i == near) continue
            val d = Math.abs(i - near)
            if (d < bd) { bd = d; best = i }
        }
        return best
    }

    private fun magnetStep(f: Frame, now: Long, ch: BooleanArray) {
        val n = slots.size
        for (i in 0 until n) {
            if (ch[i] && stable[i] == Classifier.OCC) watchUntil[i] = now + 900L
        }
        val t = mgTarget
        if (t < 0 || t >= n) return
        if (mgSigPending && stable[t] == Classifier.OCC) {
            mgSig = sigNow(f, t)
            mgSigPending = false
        }
        takeVerify(now)
        if (!armed) return

        if (mgPhase == 0) {
            val st = stable[t]
            if (st == Classifier.EMPTY || st == Classifier.LOCKED) {
                if (mgLeftAt == 0L) mgLeftAt = now
                val k = findTarget(f, now, t)
                if (k >= 0) {
                    mgTarget = k          // he only changed seat
                    mgLeftAt = 0L
                } else if (now - mgLeftAt >= (if (mgSig != null) 140L else 0L)) {
                    mgLeftAt = 0L
                    mgPhase = 1
                    mgWantUp = false
                    exitNow(now)
                }
            } else {
                mgLeftAt = 0L
            }
        } else {
            val k = findTarget(f, now, -1)
            if (k >= 0) {
                mgTarget = k
                mgPhase = 0
                mgWantUp = true
                mgWantAt = now
            }
        }
        if (mgWantUp) upStep(now)
        exitVerify(now)
    }

    /** He left: tap my own seat, the pop-up handler then presses "Exit mic". */
    private fun exitNow(now: Long) {
        val me = mgMe
        if (me < 0 || me >= slots.size || stable[me] != Classifier.OCC) {
            say(R.string.mg_nome)
            return
        }
        mgLastMe = me
        mgExitSeat = me
        mgExitTries = 2
        mgExitAt = now + 900L
        tapSlot(me, true)
        say(R.string.mg_exit)
    }

    private fun exitVerify(now: Long) {
        val s = mgExitSeat
        if (s < 0) return
        if (stable[s] != Classifier.OCC) { mgMe = -1; mgExitSeat = -1; return }
        if (now >= mgExitAt) {
            if (mgPhase == 1 && mgExitTries > 0) {
                mgExitTries--
                mgExitAt = now + 900L
                tapSlot(s, true)
            } else {
                mgExitSeat = -1
            }
        }
    }

    /** He is back: go up again (my old seat if it is free, otherwise the nearest free one). */
    private fun upStep(now: Long) {
        if (now < mgBusyUntil) return
        if (mgMe >= 0 && mgMe < slots.size && stable[mgMe] == Classifier.OCC) { mgWantUp = false; return }
        if (now - mgWantAt > 8000L) { mgWantUp = false; return }
        val s = pickFree(mgTarget)
        if (s < 0) return
        mgWantUp = false
        mgBusyUntil = now + 600L
        mgTakeSeat = s
        mgTakeAt = now + 1100L
        mgTakeTries = 2
        tapSlot(s, true)
        say(R.string.mg_up, s + 1)
    }

    private fun takeVerify(now: Long) {
        val s = mgTakeSeat
        if (s < 0) return
        if (stable[s] == Classifier.OCC) { mgMe = s; mgLastMe = s; mgTakeSeat = -1; return }
        if (now >= mgTakeAt) {
            if (mgTakeTries > 0 && mgPhase == 0) {
                mgTakeTries--
                val s2 = if (stable[s] == Classifier.EMPTY) s else pickFree(mgTarget)
                if (s2 >= 0) { tapSlot(s2, true); mgTakeSeat = s2; mgTakeAt = now + 1100L } else mgTakeSeat = -1
            } else {
                mgTakeSeat = -1
            }
        }
    }
}
