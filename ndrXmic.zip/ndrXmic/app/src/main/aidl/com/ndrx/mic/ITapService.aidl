package com.ndrx.mic;

interface ITapService {
    // transaction code reserved by Shizuku
    void destroy() = 16777114;

    // injects a touch tap straight into the input system; returns false when injection is not possible
    boolean tap(float x, float y, boolean twice) = 1;

    boolean ping() = 2;
}
